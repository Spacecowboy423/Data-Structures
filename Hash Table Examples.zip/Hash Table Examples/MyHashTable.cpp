/*
Program Name: Hash Tables
Author: Michael Krause
Last Update: 3/01/2022
Purpose: To use the prebuild declarations and function definitions to create a program using the methods from the built classes to
show how to use a Hash Table and Hash Functions.
*/
#include "HashTable.h"

//Don't need any of these functions, I rewrote them in the 'hash' method contained in 'HashTable.cpp'
//I left them here as developer testing to direct test my functions if you wanted. There are command lines at the end of the program
//that can be used to manually enter whatever data you want to test my hash functions.
//int hash1(string key, int tableLength) {
//    int value = 0;
//
//    for (int i = 0; i < key.length(); i++) {
//        value += key[i];
//    }
//
//    return value / 23 * 13 % tableLength;
//}
//int hash2(string key, int tableLength) {
//    int value = 0;
//
//    for (int i = 0; i < key.length(); i++) {
//        value += key[i];
//    }
//
//    return value / 23 % tableLength;
//}
//int hash3(string key, int tableLength) {
//    int value = 0;
//
//    for (int i = 0; i < key.length(); i++) {
//        value += key[i];
//    }
//
//    return value * 13 % tableLength;
//}
//int hash4(string key, int tableLength) {
//    int value = 0;
//
//    for (int i = 0; i < key.length(); i++) {
//        value += key[i];
//    }
//
//    return value * 599 % tableLength;
//}

//void function to print the hash menu
void printHashMenu() {
    cout << "***************************************" << endl;
    cout << "**      1. Use Hash Function 1       **" << endl;
    cout << "**      2. Use Hash Function 2       **" << endl;
    cout << "**      3. Use Hash Function 3       **" << endl;
    cout << "**      4. Use Hash Function 4       **" << endl;
    cout << "**      5. Use Hash Function 5       **" << endl;
    cout << "***************************************" << endl;
}

//void function to print the main menu
void printMain() {
    cout << "***********************************" << endl;
    cout << "**      1. Insert Book           **" << endl;
    cout << "**      2. Remove Book           **" << endl;
    cout << "**      3. Search Book           **" << endl;
    cout << "**      4. Retrieve Book         **" << endl;
    cout << "**      5. Print Table Row       **" << endl;
    cout << "**      6. Print Table           **" << endl;
    cout << "**      7. Print Histogram       **" << endl;
    cout << "**      8. End Program           **" << endl;
    cout << "***********************************" << endl;
}

int main() {

    //Program variables
    char HashMenu, MainMenu;
    bool boolean = true;
    string key;
    //Program hashtable and linked list node
    HashTable Hash;
    Item* node;

    //Menu to choose with hash function the user would like to use for iteration of program
    while (boolean) {
        try {
            printHashMenu();
            cin >> HashMenu;

            if (HashMenu >= '1' && HashMenu <= '5') { //If user enters correct option from menu set the value and move to main menu
                cout << "Hash Function " << HashMenu << " will be used to store items." << endl;
                Hash.setHashFunction(HashMenu);
                boolean = false;
            }
            else {
                throw string("Invalid Input. Must choose a proper hash function.");
            }

        }
        catch (string err) {
            cout << err << endl;
            cin.clear();
            cin.ignore(1, '\n');
        }
    }

    //Reset boolean to true for main menu while loop
    boolean = true;

    while (boolean) {		//While loop runs until user enters 8

        printMain();
        cin >> MainMenu;

        try {					//Try catch block handles any exceptions from users entry for menu
            switch (MainMenu) {		//switch case runs through the possible user entries
            case '1':
                cout << "Please enter a book title to insert into the table." << endl;
                cin.clear();                                //clear input stream
                cin.ignore(1, '\n');                        //ignore anything left in input stream
                getline(cin, key);                          //grab entire user entry for key
                node = new Item{ key, NULL };              //create a node with the value as our key and the link to the next node set to NULL
                Hash.insertItem(node);                      //Function will insert the node into the linked list at the proper index in the array
                break;

            case '2':
                cout << "Please enter a book title to remove from the table." << endl;
                cin.clear();
                cin.ignore(1, '\n');
                getline(cin, key);

                if (Hash.removeItem(key)) { //returns true if the item is removed from the hash table, returns false if not
                    cout << "Item was removed successfully." << endl;
                    break;
                }
                else {
                    cout << "Cannot remove. Item is not contained within Hash Table." << endl;
                    break;
                }

            case '3':
                cout << "Type the book you are looking for." << endl;
                cin.clear();
                cin.ignore(1, '\n');
                getline(cin, key);

                if (Hash.isItemAtEqual(key)) { //returns true if key is contained within the Hash Table
                    cout << "Book is stored in the Hash Table." << endl;
                    break;
                }
                else {
                    cout << "Book is not contained within the Hash Table." << endl;
                    break;
                }

            case '4':
                cout << "Enter the book you would like to retrieve." << endl;
                cin.clear();
                cin.ignore(1, '\n');
                getline(cin, key);

                if (Hash.getItemByKey(key)) { //Grabs the key value and returns true if successful
                    node = Hash.getItemByKey(key);
                    cout << "Book Title: " << node->key << endl;
                    break;
                }
                else {
                    cout << "Cannot retrieve book. Not contained within the Hash Table." << endl;
                    break;
                }
            case '5':
                cout << "Enter the title of the book for the row you would like to print." << endl;
                cin.clear();
                cin.ignore(1, '\n');
                getline(cin, key);
                if (Hash.isItemAtEqual(key)) { //if item is contained within the hash table then attempt to print the row it's contained in
                    cout << "Items in the row are:" << endl;
                    Hash.printTableRow(key);
                    break;
                }
                else {
                    cout << "Item does not exist within Hash Table." << endl;
                    break;
                }

            case '6':
                Hash.printTable(); //existing method to print the table with a cool display of the information
                break;

            case '7':
                Hash.printHistogram(); //existing method to print the number of elements contained at each index of the array.
                break;

            case '8':
                boolean = false;
                cout << "Thanks for using the program. Have a great day!" << endl;		//Print ending message to user
                break;

            default:
                throw string("Please only enter a number 1-5 from the main menu.");		//Throw string into ostream for exception handling
            }//end switch
        }//end try

        catch (string err) {
            cout << err << endl;
            cin.clear();
            cin.ignore(1, '\n');
        }//end catch
    }//end while

    //Test cases for hash functions 'tomato' represents any string input to be hashed, '45' represents the theoretical size 
    //of the array it would be stored in
    //cout << "\nNot part of the program. Developer output to test if hash functions are working properly." << endl;
    //cout << "Hash 1: " << hash1("tomato", 45) << endl;
    //cout << "Hash 2: " << hash2("tomato", 45) << endl;
    //cout << "Hash 3: " << hash3("tomato", 45) << endl;
    //cout << "Hash 4: " << hash4("tomato", 45) << endl;
    //cout << "Hash 1: " << hash1("tomato", 45) << endl;
    //cout << "End of Developer output." << endl;

    return 0;
}//end main
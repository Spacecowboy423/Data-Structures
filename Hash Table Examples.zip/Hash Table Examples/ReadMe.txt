Program Name: Hash Tables
Author: Michael Krause
Last Update: 3/01/2022
Purpose: To use the prebuild declarations and function definitions to create a program using the methods from the built classes to
show how to use a Hash Table and Hash Functions.

Source.cpp is the original source file with the class. I commented the whole thing out.
MyHashTable.cpp is my source file using the class, methods, and functions I added to make my program.

Instructions:

For this assignment complete the following programming exercises.  In addition to the requirements stated in these exercises for 
any classes that you create you should also create a class diagram using UML and a use case diagram.

Complete the following steps:
Write definition of search, isItemAtEqual, retrieve, remove, print, constructor, and destructor for class hashT based upon a method 
of your choice from the powerpoint or otherwise. Write a test program to test with at least 3 different hashing functions.


My Implementation:

The retrieve, remove, print, and constructors were already defined. The search function is not defined or declared in the 
program. I did not create a search function but that is because using the isItemAtEqual() method and the getItemAtKey() function
are doing what the search function would do, so instead I used the both of them in conjunction to create a search. The isItemAtEqual I
declared it in HashTable.h and then defined it in HashTable.cpp. It simply takes in the key value from the user and converts it in the
proper hash function to then check the array at that index and returns true or false if an item is there. If so then I use the 
getItemAtKey function to grab the node at that index. I copy the information to a temporary node made in the main program and then
print the information stored in that node. 

The program already had a hash function they were using the table, I reworked it and added 4 more hash functions that can be used 
during the program. At the start of the program I give the user the option to choose what hash function will be used for the program. 
The hash function then determines the hash of every key value entered and determines what index the information will be stored. The 
user has the option to insert new items, remove items, search for an item, retrieve an item. I added a print function that will take
the key value entered by the user and print out all the information in that row using the linked list aspect. However, because of the
linked list it will only print from that object to the end of that row. It does not print the whole row. The program had a sweet print 
table and print table in a histogram function that I used to display where and how information is being stored. The length of the array 
is set to 13 by default in the header files but could be changed to any size or a user determined size but for the program I left it 
at 13.

The hash functions in the source.cpp are there to test my hash functions that are in the HashTable.cpp hash() function. The string
"tomato" represents a key value coming in and the int 45 represents the size of the array being used. Both hypothetical just for testing.
The hash functions add the asc values of each char in the string to get a sum. Then I just used random arithmetic, and made sure to use
prime number values in my arithmetic, and a modulus operator with the array size to create the hash value to determine it's place in the
hypothetical array. 

Every time the program retrieves or searches from the hash table it needs to take in a potential key value, run it through the same
hash function operation, and then check if there is a value stored at that hashed location. If so the program will continue running
what operation it was attempting. If not the program will return with some error message that the key value entered by the user does
not match anything within the Hash Table. 



Notes from pumpkin programmer on a Hash Function:

A hash function decides where to store and retrieve items in a hash table. It takes in an item key as its parameter and 
returns an index location for that particular item. Generally, a hash function uses modulo arithmetic. In particular, 
a key value is divided by the table length to generate an index number in the table. This index number refers to a 
location, or bucket, in the hash table.

Here�s an example: Suppose the hash function takes in a string as its parameter, and then it adds up the ASCII values 
of all of the characters in that string to get an integer. If the key is �pumpkin,� then the sum of the ASCII values would 
be 772. After that, the hash function takes the modulus of this number by the table length to get an index number. If the 
table length is 13, then 772 modulo 13 is 5. So the item with the key �pumpkin,� would go into bucket # 5 in the hash table.

int hash( string key ){
    int value = 0;
    for ( int i = 0; i < key.length(); i++ ){
        value += key[i];
        }
    return value % tableLength;
}
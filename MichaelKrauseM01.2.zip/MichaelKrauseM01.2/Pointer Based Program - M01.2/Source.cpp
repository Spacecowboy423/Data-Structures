﻿/*
Program Name: Pointers
Author: Michael Krause
Last Update: 1/30/2022
Purpose: To give an in-depth and detailed explaination behind the use and practice of arithemtic with pointers. 
*/

#include <iostream>;
#include <string>;
using namespace std;

//Pointer Class
class Pointers {
private:
	//Fields
	int number, number1; 
	int *ptr, *ptr2, *ptrarray;

public:
	//Default Constructor
	Pointers() {
		this->number = 1;
		this->number1 = 5;
		ptr = &number;
		ptr2 = &number1;
	}

	//Parameterized Constructor
	Pointers(int number, int number1) {
		this->number = number;
		this->number1 = number1;
		ptr = &this->number;
		ptr2 = &this->number1;
	}

	//Destructor
	~Pointers() {
		//
	}

	//Accessors with pointers
	int getNumber() {
		return *ptr;
	}
	int getNumber1() {
		return *ptr2;
	}

	//Mutators with pointers
	void setNumber(int number) {
		*ptr = number;
	}
	void setNumber1(int number1) {
		*ptr2 = number1;
	}
	
	//Methods
	int Add() {
		return *ptr + *ptr2;
	}
	int Subtract() {
		return *ptr2 - *ptr;
	}
	int Multiply() {
		return *ptr * *ptr2;
	}
	int Divide() {
		return *ptr2 / *ptr;
	}
	void Increment(){
		ptrarray++;
	}
	void Decrement(){
		ptrarray--;
	}
	
	//toString
	string toStringNumber() {
		return to_string(*ptr);
	}
	string toStringNumber1() {
		return to_string(*ptr2);
	}
	
	//The Big Show
	void RunProgram() {
	/*
	Initialize pointers to the corresponding address of the variables created above using the address-of (&) symbol.
	The pointers can now reference the information stored in the memory location or the pointers can access the address
	of where the information is stored in memory.
	*/

		cout << "*ptr can access the information stored in 'number': " << getNumber() << endl;
		cout << "ptr can access the address of the memory location of 'number': " << ptr << endl;
		cout << "*ptr2 holds the integer " << getNumber1() << " stored in 'number2': " << getNumber1() << endl;
		
		cout << "\nPointers can also be used for Arithmetic just like variables." << endl;
		cout << "Pointers can be used for addition by value..." << endl;
		*ptr += 1;//increases value in memory using pointer by the value 1
		cout << "ptr pointer value has been increased by 1 to: " << getNumber() << endl;
		
		cout << "\nPointers can also be used for addition by reference. Like from another pointer..." << endl;
		*ptr += *ptr;//increases value in memory by reference of itself
		cout << "ptr pointer has now double by adding it to itself to get: " << getNumber() << endl;
		
		cout << "\nWe can subtract two different pointers of the same type. *ptr2 - *ptr = " << Subtract() << endl;
		cout << "Now we can also add two different pointers of the same type. *ptr + *ptr2 = " << Add() << endl;
		cout << "*ptr is currently: " << getNumber() << endl;
		cout << "*ptr2  is currently: " << getNumber1() << endl;

		cout << "\nBecause the arithemetic was done in the output stream for the last two operations the information was not stored in memory." << endl;
		cout << "To decrease the value of ptr2 pointer by the value 2 we do the same thing as for normal addition." << endl;
		*ptr2 -= 2;//decreases value in memory using pointer by the value 2
		cout << "ptr2 pointer value has been decreased by 2 to: " << getNumber1() << endl;
		
		cout << "\nPointers can be used to multiply other pointers of the same type without changing the value stored in memory (*ptr2 * *ptr) gives: " << Multiply() << endl;
		cout << "\n*ptr is currently: " << getNumber() << endl;
		cout << "*ptr2  is currently: " << getNumber1() << endl;
		
		*ptr2 *= 2;//increases value in memory using pointer by multiplying with the value 2
		cout << "\nPointers can be multiplied and change the value like *ptr2 * 2 to get: " << getNumber1() << endl;
		cout << "\n*ptr is currently: " << getNumber() << endl;
		cout << "*ptr2  is currently: " << getNumber1() << endl;

		*ptr2 += 2;//increases value in memory using pointer by adding the value 2
		cout << "\nAdd 2 to the value in memory real quick..." << endl;
		cout << "*ptr is currently: " << getNumber() << endl;
		cout << "*ptr2  is currently: " << getNumber1() << endl;
		
		cout << "\nWe can also use pointers to divide like (*ptr2 / *ptr) gives: " << Divide() << endl;

		//When using the (++) and (--) operators to increment a pointer it's a good idea to only use them with arrays, or in a situation
		//where the next increment up or down holds a variable in that memory location. Otherwise what will be returned is the address 
		//of where the pointer has been incremented or decremented to. It will not increase or decrease the value stored in the memory location
		//by one. It basically telling the pointer to look in a new location in memory one bit higher or one bit lower without changing
		//the value at the original memory location.

		//Declare and Initialize array
		int array[] = { 0, 1, 2, 3, 4, 5 };
		//Initialize pointer
		ptrarray = array;

		cout << "\nFinally, using pointers with arrays is the best way to show and explain the incrementing and decremnting process." << endl;
		cout << "Information stored in array(0, 1, 2, 3, 4, 5)" << endl;
		cout << "Information stored in array at index 0: " << array[0] << endl;
		cout << "Information stored in array at index 1 using pointer: " << ptrarray[1] << endl;
		
		//To use the Arithemetic operators (++) and (--) to print the array you can increment the pointer to point to the next location in memory
		//for loop to run through the array
		for (int i = 0; i < size(array); i++) {
			cout << *ptrarray << endl;
			//Increment method increases the index by one
			Increment();
		}

		//add space in between loops
		cout << endl;

		//for loop to run through the array
		for (int i = size(array); i > 0; i--) {
			//Decrement method decreases the index by one
			Decrement();//i has become 6(the size of the array) but 6 is out of bounds so we need to decrease it by 1 or it will print the next memory location one bit up
			cout << *ptrarray << endl;
		}

		//To check my work, if everything was correct then the index should point to 1 and print the value '1'
		Increment();
		cout << "\n" << *ptrarray << endl;
		//Then point to index 2 and print the value '2'
		Increment();
		cout << *ptrarray << endl;
	}
};
//
//Main
//
int main() {
	//Create class using parameterized constructor
	Pointers Pointer(3, 9);
	//Call RunProgram method from object class
	Pointer.RunProgram();
	//Call destructor
	Pointer.~Pointers();
}
//Program Statement/Problem to Solve
What is pointer arithmetic? How is it performed? (1 point)
Explain 5 with a programming example - include the efficiency of the program in Big O notation. (25 points)

//Program Explanation of Solution:
Since the goal of my algorithm is to explain what pointer arithmetic is and show how it is used properly I thought the best way to
do that way to make a simple algorithm that will run through pointer arithmetic automatically and explain the process along the way.
This way the user can use the console window to follow along with the algorithm line by line to understand pointers and pointer
arithmetic. 

The first section walks the user through the process of using pointers with variables and how to use basic arithmetic using the 
pointers. I explain the difference between declaring and initializing pointers and update the user with each arithmetic done to 
help the user follow along. I also show the how to use the pointer to print the address or to print the information stored at that
address. Using *pointer vs pointer. 

The next section then explains how to use pointers with an array and the increment and decrement process with pointers. Then use 
two for loops to run through the array using the pointer to the array to output the data from the array. The first loop increments 
through the array from low bound to high bound. The second loop decrements through the array from high bound to low bound. The 
final two statements are just an extra explanation of how to increment the pointer of the array by 1. 

All of the Accessor, Mutators, Methods, and toStrings still use the pointers I created for the program instead of using the 
variable or the built in (this) pointer included for classes. I think I actually used both (this) and the declared pointers from the
class in the constructors but otherwise I only used the declared pointers in the rest of the program to better show off the use of
pointers. This made sense to me instead of flip-flopping between the two pointers. 

I used the parameterized constructor to change the values of number and number1 to test what I had built. I made sure to only use 
proper integers for testing becuase since this was just and explanation algorithm I did not see the need to make this a user driven
or menu driven program. So there was no need for input validation or exeception handling. I tested the program with proper integer
values (2, 10), (1, 5), (3, 9) and made sure the first entry is smaller than the second entry due to the subtraction method used in
the algorithm.
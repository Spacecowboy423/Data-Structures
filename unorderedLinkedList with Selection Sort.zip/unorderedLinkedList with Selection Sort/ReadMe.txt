/*
Program Name: Selection Sort of unorderedLinkedList
Author: Michael Krause
Last Update: 3/22/2022
Purpose: To create an unordered linked list of 1, 10, 100, and 1000 random numbers and then sort the list using
the selection sort method. Once done print the now ordered linked list back to the user.
*/

Problem Statement:
Write and test a program that uses a selection sort on an ordered linked list. 
Compare the efficiency between the merge and selection sort.
Test with AT LEAST lists with these number of elements
1
10
100
1000
You will need to know the time in milliseconds to run each and graph the comparison of n vs time.

My Solution:
I implemented a menu for the user to decide how many random numbers to put in the linked list. I used a try
catch block to handle invalid input from the user and to protect the program integrity. Inside the try catch 
block I have a switch statement to catch the proper input from the user. Each case is doing the same thing, inserting
random numbers into the linked list, the only difference is the number of numbers being inserted into the list. 

To ensure that random numbers are inserted each iteration I used the srand function with the time(0) command to
give the random functin a different seed to begin it's random number generation. Otherwise it would be the same
numbers every time and I wanted to ensure any numbers entered would be ordered correctly. 

Once the proper number of numbers are inserted into the list the selection sort function is called to begin the
sorting process. Originally I tried to sort the list by sorting the nodes instead of sorting the numbers. I tried
to find the node with the smallest value and then place that node in it's proper place by swapping it with the node
currently in that position. This was much harder to do since I had to track the adjacent nodes and change the links
of the nodes. I managed to get close but I couldn't get it to work properly. So I started over and redid my program
to find the node with the smallest value and swap the value with the node in currently in that position instead of 
swapping the nodes position and changing the links in each node.

With each search and sort there is ultimately one less node the selection sort needs to run through and check, 
so as the program continues it gradually picks up speed because it has to search and sort less. I start the search
with my node traversing the list at the first position. Once the lowest value is placed in the first position the 
node traversing the list is moved forward one position and the next lowest number is found swapped with whatever
value is currently in that position. minLocation finds the node with the lowest value, swap will switch the values
of the two nodes, and the selectionSort progresses through the list one node at a time and calls the other functions
until the list has placed everything in the proper order and then returns to the main program.

At this point the printSelectionSort function is called to display the now ordered linked list back to the user with the
time in milliseconds that it took for the sort to execute. The program then asks the user to continue or end the
program. I didn't worry about any exception handling at this point because the only input other than the proper input
to continue the program will immediatly end the program.

To try and get the best reading of the execution time I snapped an instance of the system time the moment after
the user chooses a correct option from the menu and snap an instance of the system time again the moment the final 
number from the list has been printed. I then subtract the stop time from the start time to get the amount of time
for the execution. Initially I attempted to do it in milliseconds but it wasn't capturing the milliseconds correctly
and would give me 0 when it should have been 0.(some decimal). So by grabbing the time in microseconds and then
converting it to milliseconds it gave me the correct decimal value.
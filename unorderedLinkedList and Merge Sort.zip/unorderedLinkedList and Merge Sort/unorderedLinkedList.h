#pragma once
#include <iostream>
using namespace std;

//Definition of the node
template <class Type>
struct nodeType {
	Type info;
	nodeType<Type>* link;
};

template <class Type>
class unorderedLinkedList {
protected:
	int count = 0;
	nodeType<Type> *first;
	nodeType<Type> *last;

public:
	bool search(const Type& searchItem) const;
		//Function to determine whether searchItem is in the list.
		//Postcondition: Returns true if searchItem s in the list,
		//				 otherwise the value false is returned.

	void insertFirst(const Type& newItem);
		//Function to insert newItem at the beginning of the list.
		//Postcondition: 'first' points to the new list, newItem is
		//				 inserted at the beginning of the list,
		//				 'last' points to the last node in the list,
		//				 and count is incremented by 1.

	void insertLast(const Type& newItem);
		//Function insert newItem at the end of the list.
		//Postcondition: 'first' points to the new list, newItem
		//				 is inserted at the end of the list.
		//				 'last' points to the last node in the list, 
		//				 and count is incremented by 1.

	void deleteNode(const Type& deleteItem);
		//Function to delete deleteItem from the list.
		//Postcondition: If found, the node containing
		//				 deleteItem is deleted from the list.
		//				 'first' points to the first node, 'last'
		//				 points to the last node of the updated
		//				 list, and count is decremented by 1.

	/////////////////////////////////////////////////////////////////////////////
	void divideList(nodeType<Type>* first1, nodeType<Type>*& first2);

	nodeType<Type>* mergeList(nodeType<Type>* first1, nodeType<Type>*& first2);

	void recMergeSort(nodeType<Type>*& head);

	void mergeSort();

	void printMerge();

	~unorderedLinkedList();
};

template <class Type>
bool unorderedLinkedList<Type>::search(const Type& searchItem) const {	//i think needs the list sent to it
	
	nodeType<Type>* current;	//pointer to traverse the list
	bool found = false;
	
	current = first;			//set current to point to the first node in the list

	while (current != nullptr && !found) {	//search the list
		if (current->info == searchItem) {		//searchItem is found
			found = true;
		}
		else {
			current = current->link;			//make current point to the next node
		}
	}//end while
	
	return found;
}//end search

template <class Type>
void unorderedLinkedList<Type>::insertFirst(const Type& newItem) {
	
	nodeType<Type>* newNode;	//pointer to create the new node
	newNode = new nodeType<Type>;	//create the new node
	
	newNode->info = newItem;	//store the new item in the node
	newNode->link = first;		//insert newNode before first
	first = newNode;			//make first point to the actual first node

	count++;					//increment count

	if (last == nullptr) {		//if the list was empty, newNode is also the last node in the list
		last = newNode;
	}
}//end insertFirst

template <class Type>
void unorderedLinkedList<Type>::insertLast(const Type& newItem) {
	
	nodeType<Type>* newNode;	//pointer to create the new node
	newNode = new nodeType<Type>;	//create the new node

	newNode->info = newItem;	//store the new item in the node
	newNode->link = nullptr;	//set the link field of newNode to nullptr

	if (first == nullptr) {		//if the list is empty, newNode is both the first and the last node
		first = newNode;
		last = newNode;
		count++;	//increment count
	}
	else {
		last->link = newNode;		//insert newNode after last
		last = newNode;			//make last point to the actual last node in the list

		count++;	//increment count
	}
}//end insertLast

template <class Type>
void unorderedLinkedList<Type>::deleteNode(const Type& deleteItem) {
	
	nodeType<Type> *current;	//pointer to traverse the list
	nodeType<Type> *trailCurrent;	//pointer just before current
	bool found;

	if (first == nullptr) {		//Case 1: the list is empty
		cout << "Cannot delete from an empty list." << endl;
	}
	
	else {
		if (first->info == deleteItem) {		//Case 2
			current = first;
			first = first->link;
			count--;

			if (first == nullptr) {		//the list has only one node
				last = nullptr;
			}

			delete current;
		}
		else {					//search the list for the node with the given info
			found = false;
			trailCurrent = first;		//set trailCurrent to point to the first node

			current = first->link;		//set current to point to the second node

			while (current != nullptr && !found) {
				if (current->info != deleteItem) {
					trailCurrent = current;
					current = current->link;
				}
				else {
					found = true;
				}
			}//end while

			if (found) {	//Case 3: if found, delete the node
				trailCurrent->link = current->link;
				count--;

				if (last == current) {	//node to be deleted was the last node
					last = trailCurrent;	//update the value of last
				}

				delete current;		//delete the node from the list
			}
			else {
				cout << "The item to be deleted is not in the list." << endl;
			}
		}//end else
	}//end else
}//end deleteNode

///////////////////////////
template <class Type>
void unorderedLinkedList<Type>::divideList(nodeType<Type>* first1, nodeType<Type>*& first2) {

	nodeType<Type>* middle;
	nodeType<Type>* current;

	if (first1 == nullptr) {		//list is empty
		first2 = nullptr;
	}
	else if (first1->link == nullptr) {		//list has only one node
		first2 = nullptr;
	}
	else {
		middle = first1;
		current = first1->link;

		if (current != nullptr) {		//list has more than two nodes
			current = current->link;
		}

		while (current != nullptr) {	//progress middle once and current twice until current reaches end of sublist
			
			middle = middle->link;
			current = current->link;
			
			if (current != nullptr) {
				current = current->link;
			}

		}//end while

		first2 = middle->link;	//first2 points to the first node of the second sublist

		middle->link = nullptr;		//set the link of the last node of the first sublist to nullptr
	}//end else
}//end divideList

template <class Type>
nodeType<Type>* unorderedLinkedList<Type>::mergeList(nodeType<Type>* first1, nodeType<Type>*& first2) {
	
	nodeType<Type>* lastSmall;	//pointer to the last node of the merged list
	nodeType<Type>* newHead;	//pointer to the merged list

	if (first1 == nullptr) {	//the first sublist is empty
		return first2;
	}
	else if (first2 == nullptr) {	//the second sublist is empty
		return first1;
	}
	else {
		if (first1->info < first2->info) {		//compare the first nodes
			newHead = first1;					//create new head node from first 1
			first1 = first1->link;				//set first1 to the next node
			lastSmall = newHead;				//set the last node to the first node since currently holds one item
		}
		else {
			newHead = first2;					//set first2 as the new head node
			first2 = first2->link;				//move first2 to the next node
			lastSmall = newHead;				//set last node to head node, currently only one item
		}

		while (first1 != nullptr && first2 != nullptr) {
			
			if (first1->info < first2->info) {		//compare the two nodes; similar to above but the goal is to expand the list on both ends until the two lists are merged in the proper order
				lastSmall->link = first1;			
				lastSmall = lastSmall->link;
				first1 = first1->link;
			}
			else {
				lastSmall->link = first2;
				lastSmall = lastSmall->link;
				first2 = first2->link;
			}
		}//end while

		if (first1 == nullptr) {	//first sublist exhausted first
			lastSmall->link = first2;
		}
		else {		//second sublist exhausted first
			lastSmall->link = first1;
		}

		return newHead;
	}//end else
}//end mergeList

template <class Type>
void unorderedLinkedList<Type>::recMergeSort(nodeType<Type>*& head) {
	
	nodeType<Type>* otherHead;

	if (head != nullptr) {				//if the list is not empty
		if (head->link != nullptr) {			//if the list has more than one node
			divideList(head, otherHead);		//function to divide the list into two seperate lists
			recMergeSort(head);					//recursive function sorts the lower list
			recMergeSort(otherHead);			//recusrsive function sorts the upper list
			head = mergeList(head, otherHead);	//function to merge the two lists back into one
		}
	}
}//end recMergeSort

template <class Type>
void unorderedLinkedList<Type>::mergeSort() {
	
	recMergeSort(first);		//Pass first to the recursive merge sort function

	if (first == nullptr) {		//If first is null, list is empty
		last = nullptr;
	}
	else {						//else set last to the last node in the list
		last = first;
		while (last->link != nullptr) {
			last = last->link;
		}
	}
}//end mergeSort

template <class Type>
void unorderedLinkedList<Type>::printMerge() {
	
	nodeType<Type>* current;	//pointer to traverse the list
	current = first;				//set current to point to the first node in the list
	int ListNumber = 1;					//used to track the current number

	while (current != nullptr) {
		cout << ListNumber << ": " << current->info << endl;		//Print the current item number with the info from the current node
		current = current->link;									//Move current to the next node in the linked list
		ListNumber++;
	}

}

template <class Type>
unorderedLinkedList<Type>::~unorderedLinkedList() {
	
	nodeType<Type>* current;		//pointer to traverse the list

	while (first != nullptr) {		//If the list is not empty, delete it
		
		current = first;			//set current to point to the first node in the list
		first = first->link;		//set first to the next node in the linked list
		delete current;				//delete the node stored in current
	
	}//end while

}//end destructor


/*

4 medications:
	pain - narco 1 tablet by mouth every 6 hours for up to 5 days (don't go over 4000 mg, no additional drugs, no tylenol or Ib)
	zophran - 1 tablet every 8 hours as needed under the tongue
	stool softener - 1 tablet by mouth daily for 5 days
	sodium chloride spray for nostrils - 1 spray into each nostril twice a day, while awake 4 sprays to each nostril. 
	Aquafore to insition area couple times a day to keep from drying out.
	NO BLOWING NOSE FOR 2 WEEKS!
	No ice or ice packs
	Hydrogen peroxide to clean nose
	No shower for 24 hours 

Vision goes bad seek medical attention immedietely
Continuous clear liquid from nose or salty taste when swallowing, csf leak, seek medical attention
No blowing nose or putting anything in it.
If need to sneeze try and sneeze with mouth open to releave pressure
Significant nose bleeds use asprin spray and apply light pressure, after 25 minutes it's still bleeding seek medical attention

Health page with number and concerns

Number for ent clinic, if can't reach try the other number
March 25th telephone visit at 11 a.m.
April 12th follow up with Dr. Vernan at 9:20 a.m.

*/
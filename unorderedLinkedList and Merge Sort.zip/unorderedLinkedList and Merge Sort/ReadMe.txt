/*
Program Name: Sorting an Unordered Linked List
Author:	Michael Krause
Last Update: 3/23/2022
Purpose: The goal is to create an unordered linked list of 1, 10, 100, and 1000 random numbers and then sort the list using
the merge sort method. Once the two sublists have been merged back together print the now ordered linked list back to the user.
*/

Problem Statement:
Write and test a program that uses a merge sort on an unordered linked list. 
Compare the efficiency between the merge and selection sort.
Test with AT LEAST lists with these number of elements
1
10
100
1000
You will need to know the time in milliseconds to run each and graph the comparison of n vs time.

My Solution:
I implemented a menu for the user to decide how many random numbers to put in the linked list. I used a try
catch block to handle invalid input from the user and to protect the program integrity. Inside the try catch 
block I have a switch statement to catch the input from the user. Each case is doing the same thing, inserting
random numbers into the linked list, the only difference is the number of numbers being inserted into the list. 

To ensure that random numbers are inserted each iteration I used the srand function with the time(0) command to
give the random functin a different seed to begin it's random number generation. Otherwise it would be the same
numbers every time and I wanted to ensure any numbers entered would be ordered correctly. 

Once the proper number of numbers is inserted the mergeSort function is called to divide the list into an upper
and a lower sublist. The recursive functions keep dividing each list until 1 number remains, it then reassembles
the upper and lower sublist into the proper order before merging the lists back together by comparing the two lists
together and inserting the sublist back into the main list in the proper order before returning to the main program.
At this point the printMerge function is called to display the now ordered linked list back to the user with the
time in milliseconds that it took for the sort to execute. The program then asks the user to continue or end the
program. I didn't worry about any exception handling at this point because the any input other than the proper input
to continue the program will immediatly end the program.

To try and get the best reading of the execution time I snapped an instance of the system time the moment after
the user chooses a correct option from the menu and snap an instance of the system time again the moment the final 
number from the list has been printed. I then subtract the stop time from the start time to get the amount of time
for the execution. Initially I attempted to do it in milliseconds but it wasn't capturing the milliseconds correctly
and would give me 0 when it should have been 0.(some decimal). So by grabbing the time in microseconds and then
converting it to milliseconds it gave me the correct decimal value.

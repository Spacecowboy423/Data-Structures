/*
Program Name: Sorting an Unordered Linked List
Author:	Michael Krause
Last Update: 3/09/2022
Purpose: The goal is to create an unordered linked list of 1, 10, 100, and 1000 random numbers and then sort the list using
the merge sort method. Once the two sublists have been merged back together print the now ordered linked list back to the user.
*/

#include "unorderedLinkedList.h"
#include <chrono>
#include <iomanip>
using namespace chrono;

int main() {

	unorderedLinkedList <int> list;
	int count = 0;
	bool boolean = true;
	char Input;

	srand(time(0));			//srand uses the time of the machine to create a new starting point for the random number generator
							//without this the program will generate the same random numbers every time the program runs
	
	cout << "The program will fill a linked list with random numbers in no particular order." << endl;
	cout << endl;

	while (boolean) {

		cout << "How many numbers would you like to have in the list?" << endl;
		cout << "1. 1 Number" << endl;
		cout << "2. 10 Numbers" << endl;
		cout << "3. 100 Numbers" << endl;
		cout << "4. 1000 Numbers" << endl;
		cout << "Input Choice: ";
		cin >> Input;
		cout << endl;

		auto start = high_resolution_clock::now();			//capture an instance of the start of the program execution 

		try {
			switch (Input) {
			case '1':
				list.insertFirst(rand());		//insert 1 random number into the list
				
				list.mergeSort();				//Sort boths lists and then merge into one
				
				list.printMerge();				//Print merged list
				cout << endl;
				break;

			case '2':
				//10 numbers in list
				while (count < 10) {

					list.insertFirst(rand());	//insert 10 random numbers into the list

					count++;					//increase count by 1
				}

				list.mergeSort();				//sort boths lists and then merge into one

				list.printMerge();				//print merged list
				cout << endl;
				break;

			case '3':
				while (count < 100) {			//insert 100 random numbers into the list

					list.insertFirst(rand());	//insert a random number into the list

					count++;					//increase count by 1
				}//end while

				list.mergeSort();			//sort boths lists and then merge into one

				list.printMerge();			//Print merged list
				cout << endl;
				break;

			case '4':
				while (count < 1000) {			//insert 1000 random numbers into the list

					list.insertFirst(rand());	//insert a random number into the list

					count++;
				}//end while

				list.mergeSort();			//sort boths lists and then merge into one

				list.printMerge();			//Print merged list
				cout << endl;
				break;

			default:
				throw string("Invalid Entry");

			}//end switch case
		}//end try block

		catch (string err) {
			cout << endl;
			cout << err << endl;
			cout << endl;
			cin.clear();
			cin.ignore(1, '\n');
		}//end catch

		auto stop = high_resolution_clock::now();										//capture an instance after the program ends
		auto durationOfSort = duration_cast<microseconds> (stop - start);				//subtract start from stop to get a total time of execution
		float duration = durationOfSort.count();										//store the execution time in microseconds
		duration = duration / 1000;														//convert from microsecond to millisecond
		cout << setprecision(3);														//control the set precision of output
		cout << "Sort time: " << duration << " milliseconds." << endl;					//print time of execution to user

		cout << "Return to main menu? ('y' or 'Y' to continue)" << endl;
		cin >> Input;
		cout << endl;

		if (Input == 'y' || Input == 'Y') {

			list.~unorderedLinkedList();	//Call destructor for next iteration
			count = 0;						//Reset count to zero for next iteration
		}
		else {
			boolean = false;				//change the while condition to false to end program
			break;
		}

	}//end while

}//end main
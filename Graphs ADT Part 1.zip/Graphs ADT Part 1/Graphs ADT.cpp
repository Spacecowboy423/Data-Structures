/*
Program Name: Traversing Digital Graph
Author: Michael Krause
Last Update: 4/23/2022
Purpose: Using a linked lists to create a graph and adjaceny list to store and print information. Information can be printed as the
adjaceny, breadth first, or depth first traversal.
*/

//depth
//0, 2, 54, 62, 63, 4, 11, 1, 3, 52, 9, 7, 6, 8

//breadth
//0, 2, 4, 54, 62, 63, 11, 1, 3, 6, 8, 52, 9, 7

//vertex 3
//3, 52, 9, 7

#include <iostream>
#include "GraphADT.h"
using namespace std;

int main() {

	ifstream infile;			//declare ifstream object
	infile.open("num.txt");		//open file
	int x = 0;					//count of vertices
	int j = 0;					//variable for file input
	while (j != -999) {			//run until the end token is found in file
		infile >> j;
		x++;					//increment x for each vertice from file
	}
	x--;						//decrement x to the correct number of vertices
	infile.close();				//close file

	//x is 17
	graphType graph(x);

	graph.createGraph();

	cout << endl;
	cout << "Print Graph:" << endl;
	graph.printGraph();
	cout << endl;

	cout << "Print Depth First: ";
	graph.depthFirstTraversal();
	cout << endl;

	cout << "Print Breadth First: ";
	graph.breadthFirstTraversal();
	cout << endl;
	
	cout << "Print Depth First From Vertex: ";
	graph.dftAtVertex(3);
	cout << endl << endl;
	
	cout << "Print Graph:" << endl;
	graph.printGraph();
	cout << endl;
	
	cout << "Clearing graph...";
	graph.clearGraph();
	cout << "done";
	cout << endl;

}

#pragma once
#include "unorderedLinkedList.h"
#include "linkedQueueType.h"
#include <iostream>
#include <fstream>

//***************************************************************
// Author: D.S. Malik
//
// class graphType
// This class specifies the basic operations to implement a graph.
//****************************************************************
class graphType {
public:
	bool isEmpty() const;
		//Function to determine whether the graph is empty.
		//Postcondition: Returns true if the graph is empty;
		//				 otherwise, returns false.
	
	void createGraph();
		//Function to create a graph.
		//Postcondition: The graph is created using the
		//				 adjacency list representation.
	
	void clearGraph();
		//Function to clear graph.
		//Postcondition: The memory occupied by each vertex
		//				 is deallocated.
	
	void printGraph() const;
		//Function to print graph.
		//Postcondition: The graph is printed.
	
	void depthFirstTraversal();
		//Function to perform the depth first traversal of
		//the entire graph.
		//Postcondition: The vertices of the graph are printed
		//				 using the depth first traversal algorithm.

	void dftAtVertex(int vertex);
		//Function to perform the depth first traversal of
		//the graph at a node specified by the parameter vertex.
		//Postcondition: Starting at vertex, the vertices are
		//				 printed using the depth first traversal 
		//				 algorithm.
	
	void breadthFirstTraversal();
		//Function to perform the breadth first traversal of
		//the entire graph.
		//Postcondition: The vertices of the graph are printed
		//				 using the breadth first traversal algorithm.
	
	graphType(int size = 0);
		//Constructor
		//Postcondition: gSize = 0; maxSize = size;
		//				 graph is an array of pointers to linked 
		//				 lists.
	
	~graphType();
		//Destructor
		//The storage occupied by the vertices is deallocated.
	
protected:
	int maxSize; //maximum number of vertices
	int gSize; //current number of vertices
	unorderedLinkedList<int>* graph; //array to create
									 //adjacency lists

private:
	void dft(int v, bool visited[], int vint[]);
		//Function to perform the depth first traversal of
		//the graph at a node specified by the parameter vertex.
		//This function is used by the public member functions
		//depthFirstTraversal and dftAtVertex.
		//Postcondition: Starting at vertex, the vertices are
		//				 printed using the depth first traversal 
		//				 algorithm.
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////From linkedListType
bool graphType::isEmpty() const {
	return (gSize == 0);
}//end isEmpty

void graphType::createGraph() {
	ifstream infile;
	//char fileName[50];
	int index;
	int vertex;
	int adjacentVertex;
	
	if (gSize != 0) {	//if the graph is not empty, make it empty
		clearGraph();
	}
	//cout << "Enter input file name: ";
	//cin >> fileName;
	//cout << endl;
	//infile.open(fileName);
	infile.open("numbers.txt");

	if (!infile) {
		cout << "Cannot open input file." << endl;
		return;
	}
	infile >> gSize; //get the number of vertices
	
	for (index = 0; index < gSize; index++) {
		infile >> vertex;
		infile >> adjacentVertex;

		while (adjacentVertex != -999) {
			graph[vertex].insertLast(adjacentVertex);
			infile >> adjacentVertex;
		}//end while
	}//end for
	infile.close();
}//end createGraph

void graphType::clearGraph() {
	int index;

	for (index = 0; index < gSize; index++) {
		graph[index].destroyList();
	}

	gSize = 0;
}//end clearGraph

void graphType::printGraph() const {
	for (int index = 0; index < gSize; index++) {
		cout << index << " ";
		graph[index].print();
		cout << endl;
	}//end for
	cout << endl;
} //end printGraph
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////From linkedListType

//Constructor
graphType::graphType(int size) {
	maxSize = size;										//total numbers of nodes
	gSize = 0;											//can never be more than the total of indexed agecencies
														//[0] 2 4
														//[1] 3 6 8
														//[2] 54 62 63
														//[3] 52 9 7
														//[4] 11
	graph = new unorderedLinkedList<int>[maxSize];		//total size of graph is set to maxSize
}

//Destructor
graphType::~graphType() {
	clearGraph();
}

void graphType::dft(int v, bool visited[], int vint[]) {
	int i;															//for loop iterator to traverse both vint[] and visited[]
	bool isPrinted = false;											//set each vertex to false, this is to handle dublicate values from different elements of vint[]
	for (i = 0; i < maxSize; i++) {									//for loop runs the length of vertices in the graph
		if (v == vint[i] && visited[i] == false) {					//checks the current value passed to dft is within the graph, also vint[], and that it has not been visitied
			visited[i] = true;										//if both conditions check out then change it to true to show it's been visited
			if (!isPrinted) {										//now check the 
				cout << v << " ";									//print the current vertex
				isPrinted = true;									//change the print value to true, to handle dublicate values
			}//end if
		}//end if;
	}//end for

	linkedListIterator<int> graphIt;												//create iterator for graph
	//for each vertex adjacent to v
	if (v >= 0 && v < gSize) {														//makes sure that u is never greater than gSize
		for (graphIt = graph[v].begin(); graphIt != graph[v].end(); ++graphIt) {	//graphIt is set to the first vertice of u and runs until the last adjacent vertice of u
			int w = *graphIt;														//w carries the value from (u, begin) to (u, end)
			//if (!visited[i]) {
			dft(w, visited, vint);													//recursively call the dft method with the current vertices 'w', visited[], and vint[]
			//}
		}//end for	
	}//end if
}//end dft

void graphType::depthFirstTraversal() {
	bool* visited;								//pointer to create the array to keep track of the visited vertices
	int* vint = new int[maxSize];				//pointer to array with vertices
	int i = 0;									//for loop iterator
	visited = new bool[maxSize];				//array of boolean is the same size as the number of vertices
	ifstream infile;							//infile is for the files where the graph information is
	infile.open("num.txt");						//open the file num with the graph info stored in it

	if (!infile) {								//if file cannot be opened print error message and return
		cout << "Cannot open input file." << endl;
		return;
	}//end if

	while (vint[i - 1] != -999) {				//infile runs until the end value of -999 is reached
		infile >> vint[i];						//each vertex from the file is stored into the array vint[]
		visited[i] = false;						//visited[] uses the same index as vint[] to track whether that vertex has been visited
		i++;
	}//end while
	infile.close();								//close input file

	for (int index = 0; index < gSize; index++) {	//for loop run the length of gSize
		dft(index, visited, vint);					//recursively call the depth first method and send the gSize index, visited[], and vint[]
	}//end for
} //end depthFirstTraversal

void graphType::dftAtVertex(int vertex) {
	bool* visited;								//pointer to create the array to keep track of the visited vertices
	int* vint = new int[maxSize];				//pointer to array with vertices
	int i = 0;									//for loop iterator
	visited = new bool[maxSize];				//array of boolean is the same size as the number of vertices
	ifstream infile;							//infile is for the files where the graph information is
	infile.open("num.txt");						//open the file num with the graph info stored in it

	if (!infile) {								//if file cannot be opened print error message and return
		cout << "Cannot open input file." << endl;
		return;
	}//end if

	while (vint[i - 1] != -999) {				//infile runs until the end value of -999 is reached
		infile >> vint[i];						//each vertex from the file is stored into the array vint[]
		visited[i] = false;						//visited[] uses the same index as vint[] to track whether that vertex has been visited
		i++;
	}//end while
	infile.close();								//close input file

	dft(vertex, visited, vint);					//send the vertex, all of visited[], and all of vint[]
}//end dftAtVertex

void graphType::breadthFirstTraversal() {
	linkedQueueType<int> queue;					//Declare queue from linkedQueueType of type int
	bool* visited;								//pointer to create the array to keep track of the visited vertices
	int* vint = new int[maxSize];				//pointer to array with vertices
	int i = 0;									//for loop iterator
	visited = new bool[maxSize];				//array of boolean is the same size as the number of vertices
	ifstream infile;							//infile is for the files where the graph information is
	infile.open("num.txt");						//open the file num with the graph info stored in it

	if (!infile) {								//if file cannot be opened print error message and return
		cout << "Cannot open input file." << endl;
		return;
	}//end if

	while (vint[i - 1] != -999) {				//infile runs until the end value of -999 is reached
		infile >> vint[i];						//each vertex from the file is stored into the array vint[]
		visited[i] = false;						//visited[] uses the same index as vint[] to track whether that vertex has been visited
		i++;
	}//end while
	infile.close();								//close input file

	linkedListIterator<int> graphIt;							//create iterator for graph
	for (int i = 0; i < gSize; i++) {							//main for loop runs the length of gsize 
		if (!visited[i]) {										//if index has not been visited
			queue.addQueue(vint[i]);							//add to queue
			visited[i] = true;									//change bool to show it has been visited
			cout << vint[i] << " ";								//print value

			while (!queue.isEmptyQueue()) {						//while loop runs until the queue is empty
				int u = queue.front();							//int u is used to hold the current queue front
				queue.deleteQueue();							//once queue front is grab clear the queue
				if (u >= 0 && u < gSize) {						//makes sure that u is never greater than gSize
					for (graphIt = graph[u].begin(); graphIt != graph[u].end(); ++graphIt) {	//graphIt is set to the first vertice of u and runs until the last adjacent vertice of u
						int w = *graphIt;														//w carries the value from (u, begin) to (u, end)
						for (int j = 0; j < maxSize; j++) {										//for loop runs entirely through both arrays if necessary
							if (w == vint[j] && visited[j] == false) {							//finds w between (u, begin) and (u, end) from vint[] and checks the corresponding bool value from visited[] 
								queue.addQueue(w);												//add w to the queue
								visited[j] = true;												//marks the vertex as visited in visited[] 
								cout << w << " ";												//print the vertex
								break;															//end for loop here for dublicate numbers in array.
							}//end if;
						}//end for
					}//end for
				}//end if
			}//end while
		}//end if
	}//end for
}//end breadthFirstTraversal
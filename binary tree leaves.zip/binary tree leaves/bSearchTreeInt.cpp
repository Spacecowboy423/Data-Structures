#include "bSearchTreeType.h"
#include <cassert>
#include <iostream>
using namespace std;

template<>
bool bSearchTreeType<int>::search(const int& searchItem) const {

	nodeType<int>* current;
	bool found = false;

	if (root == nullptr) {
		cout << "Cannot search an empty tree." << endl;
	}
	else {
		current = root;

		while (current != nullptr && !found) {
			if (current->info == searchItem) {
				found = true;
			}
			else if (current->info > searchItem) {
				current = current->lLink;
			}
			else {
				current = current->rLink;
			}
		}//end while
	}//end else

	return found;

}//end search

template<>
void bSearchTreeType<int>::insert(const int& insertItem) {

	nodeType<int>* current; //pointer to traverse the tree
	nodeType<int>* trailCurrent = nullptr; //pointer behind current
	nodeType<int>* newNode; //pointer to create the node

	newNode = new nodeType<int>;
	assert(newNode != NULL);
	newNode->info = insertItem;
	newNode->lLink = nullptr;
	newNode->rLink = nullptr;

	if (root == nullptr) {
		root = newNode;
	}
	else {

		current = root;

		while (current != nullptr) {

			trailCurrent = current;

			if (current->info == insertItem) {
				cout << "The insert item is already ";
				cout << "in the tree -- duplicates are not "
					<< "allowed." << endl;
				return;
			}
			else if (current->info > insertItem) {
				current = current->lLink;
			}
			else {
				current = current->rLink;
			}
		}//end while

		if (trailCurrent->info > insertItem) {
			trailCurrent->lLink = newNode;
		}
		else {
			trailCurrent->rLink = newNode;
		}
	}//end else
}//end insert

template<>
void bSearchTreeType<int>::deleteNode(const int& deleteItem) {

	nodeType<int>* current; //pointer to traverse the tree
	nodeType<int>* trailCurrent; //pointer behind current
	bool found = false;

	if (binaryTreeType<int>::root == nullptr) {
		cout << "Cannot delete from an empty tree." << endl;
	}
	else {

		current = binaryTreeType<int>::root;
		trailCurrent = binaryTreeType<int>::root;

		while (current != nullptr && !found) {
			if (current->info == deleteItem) {
				found = true;
			}
			else {

				trailCurrent = current;

				if (current->info > deleteItem) {
					current = current->lLink;
				}
				else {
					current = current->rLink;
				}
			}
		}//end while
		if (current == nullptr) {
			cout << "The item to be deleted is not in the tree." << endl;
		}
		else if (found) {
			if (current == binaryTreeType<int>::root) {
				deleteFromTree(binaryTreeType<int>::root);
			}
			else if (trailCurrent->info > deleteItem) {
				deleteFromTree(trailCurrent->lLink);
			}
			else {
				deleteFromTree(trailCurrent->rLink);
			}
		}
		else {
			cout << "The item to be deleted is not in the tree." << endl;
		}
	}//end else
}//end deleteNode

template<>
void bSearchTreeType<int>::deleteFromTree(nodeType<int>*& p) {

	nodeType<int>* current;//pointer to traverse the tree
	nodeType<int>* trailCurrent; //pointer behind current
	nodeType<int>* temp; //pointer to delete the node

	if (p == nullptr) {
		cout << "Error: The node to be deleted does not exist." << endl;
	}
	else if (p->lLink == nullptr && p->rLink == nullptr) {
		temp = p;
		p = nullptr;
		delete temp;
	}
	else if (p->lLink == nullptr) {
		temp = p;
		p = temp->rLink;
		delete temp;
	}
	else if (p->rLink == nullptr) {
		temp = p;
		p = temp->lLink;
		delete temp;
	}
	else {
		current = p->lLink;
		trailCurrent = nullptr;

		while (current->rLink != nullptr) {
			trailCurrent = current;
			current = current->rLink;
		}//end while

		p->info = current->info;

		if (trailCurrent == nullptr) { //current did not move;
									   //current == p->llink; adjust p
			p->lLink = current->lLink;
		}
		else {
			trailCurrent->rLink = current->lLink;
		}
		delete current;
	}//end else
}//end deleteFromTree

//template <class elemType>
//bSearchTreeType<elemType>::~bSearchTreeType() {
//	binaryTreeType<elemType>::destroy(binaryTreeType<elemType>::root);
//}
#include "binaryTreeType.h"
#include <iostream>
using namespace std;

template<>
const binaryTreeType<int>& binaryTreeType<int>::operator=(const binaryTreeType<int>& otherTree) {
	if (this != &otherTree) {	//avoid self-copy
		if (root != nullptr) {	//if the binary tree is not empty, destory the binary tree
			destroy(root);
		}
		if (otherTree.root == nullptr) {	//otherTree is empty
			root = nullptr;
		}
		else {
			copyTree(root, otherTree.root);
		}//end else
	}//end if
	return *this;
}//end binaryTreeType

template<>
bool binaryTreeType<int>::isEmpty() const {
	return (root == nullptr);
}//end isEmpty

template<>
void binaryTreeType<int>::inorderTraversal() const {
	inorder(root);
}//end inorderTraversal

template<>
void binaryTreeType<int>::preorderTraversal() const {
	preorder(root);
}//end preorderTraversal

template<>
void binaryTreeType<int>::postorderTraversal() const {
	postorder(root);
}//end postorderTraversal

template<>
int binaryTreeType<int>::treeHeight() const {
	return height(root);
}//end treeHeight

template<>
int binaryTreeType<int>::treeNodeCount() const {
	return nodeCount(root);
}//end treeNodeCount

template<>
int binaryTreeType<int>::treeLeavesCount() const {
	return leavesCount(root);
}//end treeLeavesCount

//////////////////////////////////////////////////////////////////////////////////
template<>
int binaryTreeType<int>::singleParentCount() const {
	return singleParent(root);
}

//////////////////////////////////////////////////////////////////////////////////

template<>
void binaryTreeType<int>::destroyTree() {
	destroy(root);
}//end destroyTree

template<>
binaryTreeType<int>::binaryTreeType(const binaryTreeType<int>& otherTree) {
	if (otherTree.root == nullptr) {	//otherTree is empty
		root = nullptr;
	}
	else {
		copyTree(root, otherTree.root);
	}
}//end binaryTreeType

template<>
binaryTreeType<int>::binaryTreeType() {
	root = nullptr;
}//end binaryTreeType

template<>
binaryTreeType<int>::~binaryTreeType() {
	destroy(root);
}//end ~binaryTreeType

template<>
void binaryTreeType<int>::copyTree(nodeType<int>*& copiedTreeRoot, nodeType<int>* otherTreeRoot) {
	if (otherTreeRoot == nullptr) {
		copiedTreeRoot = nullptr;
	}
	else {
		copiedTreeRoot = new nodeType<int>;
		copiedTreeRoot->info = otherTreeRoot->info;
		copyTree(copiedTreeRoot->lLink, otherTreeRoot->lLink);
		copyTree(copiedTreeRoot->rLink, otherTreeRoot->rLink);
	}
}//end copyTree

template<>
void binaryTreeType<int>::destroy(nodeType<int>*& p) {
	if (p != nullptr) {
		destroy(p->lLink);
		destroy(p->rLink);
		delete p;
		p = nullptr;
	}
}//end destroy

template<>
void binaryTreeType<int>::inorder(nodeType<int>* p) const {
	if (p != nullptr) {
		inorder(p->lLink);
		cout << p->info << " ";
		inorder(p->rLink);
	}
}//end inorder

template<>
void binaryTreeType<int>::preorder(nodeType<int>* p) const {
	if (p != nullptr) {
		cout << p->info << " ";
		preorder(p->lLink);
		preorder(p->rLink);
	}
}//end preorder

template<>
void binaryTreeType<int>::postorder(nodeType<int>* p) const {
	if (p != nullptr) {
		postorder(p->lLink);
		postorder(p->rLink);
		cout << p->info << " ";
	}
}//end postorder

template<>
int binaryTreeType<int>::height(nodeType<int>* p) const {
	if (p == nullptr) {
		return 0;
	}
	else {
		return 1 + max(height(p->lLink), height(p->rLink));
	}
}//end height

template<>
int binaryTreeType<int>::max(int x, int y) const {
	if (x >= y) {
		return x;
	}
	else {
		return y;
	}
}//end max

////////////////////////////////////////////////////////////////////////////////////////////
template<>
int binaryTreeType<int>::nodeCount(nodeType<int>* p) const {
	//base case
	if (p == nullptr) {
		return 0;		//return 0 if current node is empty
	}
	else {
		return (nodeCount(p->lLink) + 1 + nodeCount(p->rLink));		//direct recursive call to count all the nodes in the tree
	}
}//end nodeCount

template<>
int binaryTreeType<int>::leavesCount(nodeType<int>* p) const {
	//base case
	if (p == nullptr) {
		return 0;		//return 0 if current node is empty
	}
	else if (p->lLink == nullptr && p->rLink == nullptr) {
		return 1;		//return 1 to count the leaf node with no children attached
	}
	else {
		return leavesCount(p->lLink) + leavesCount(p->rLink);		//direct recursive call to find leaf nodes
	}
}//end leavesCount

template<>
int binaryTreeType<int>::singleParent(nodeType<int>* p) const {
	//base case
	if (p == nullptr) {		//check the node is not empty
		return 0;		//return 0 if current node is empty
	}
	if (p->lLink == nullptr && p->rLink != nullptr) {		//check if left is empty and right is not
		return 1 + singleParent(p->rLink);		//return 1 on this recursive call for the left node single parent and continue to the right node
	}
	if (p->rLink == nullptr && p->lLink != nullptr) {		//checks if right is empty and left is not
		return 1 + singleParent(p->lLink);		//return 1 on this recursive call for the right node single parent and continue to the left node
	}
	else {
		return singleParent(p->lLink) + singleParent(p->rLink);		//direct recursive call for left and right side if neither is empty
	}
}//end singleParent
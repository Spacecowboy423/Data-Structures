/*
Program Name: Recursive Reversal
Author: Michael Krause
Last Update: 3/26/2022
Purpose: To allow the user to decide upon the size of the array and then have them choose a low index and a
high index contained within the array. The program then uses recursion to reverse the order of the elements
in between the indecies chosen by the user and print the results.
*/

#include "recFun.h"

int main() {
	
	//Declare object of recFun
	recFun object;

	//Declare and Initialize an int array of size 100
	int intArray[100];

	//Declare Program Variables
	float low;
	float high;
	char Continue;
	bool boolean = true;

	//Welcome prompt
	cout << "An array of the size 100 has its elements filled with numbers from 1-100 in sequential order." << endl;
	cout << "Please enter a value from 0-98 for the low index and from 1-99 for the high index." << endl;
	cout << "When the correct values are entered the program will switch the elements of everything in between the indicated indices." << endl;
	cout << "The results will be printed back to console and the program will terminate by the user." << endl;
	cout << endl;

	while (boolean) {

		try {
			//Prompt user to enter a low and high index
			cout << "Enter a number for the low index. (0-98)" << endl;
			cin >> low;
			cout << endl;

			low = (int)low;
			object.setLow(low);

			try {
				if (object.LowCheck()) {
					object.setLow(low);
				}
				else {
					throw string("Invalid Low Input. (0-98)");
				}
			}//end try

			catch (string err) {
				cout << err << endl;			//Print thrown string from try block
				cin.clear();					//Clear the stream for the next iteration
				cin.ignore(1, '\n');			//Ignore anything left behind after the clear
				goto TerminationCheck;			//Label to traverse directly to asking for program termination or to continue
			}//end catch

			cout << "Enter a number greater than " << object.getLow() << " and less than 100 for the high index." << endl;
			cin >> high;
			cout << endl;

			high = (int)high;
			object.setHigh(high);
		
			try {
				if (object.HighCheck()) {
					object.setHigh(high);
				}
				else {
					throw string("Invalid High Input. (1-99)");
				}
			}//end try

			catch (string err) {
				cout << err << endl;			//Print thrown string from try block
				cin.clear();					//Clear the stream for the next iteration
				cin.ignore(1, '\n');			//Ignore anything left behind after the clear
				goto TerminationCheck;			//Label to traverse directly to asking for program termination or to continue
			}//end catch

			if (object.LowCheck() && object.HighCheck() && object.LowToHigh()) {
				//Fill the intArray in sequential order from 1-100
				object.recFillArray(intArray, 0);

				//Reverse entire intArray
				//object.recReverse(intArray, 0, 100 - 1);

				object.recFillArray(intArray, 0);

				//Reverse the array between user specified indices. 
				object.recReverse(intArray, object.getLow(), object.getHigh());

				cout << "Newly ordered array after reversal:" << endl;
				object.recPrintArray(intArray, 0);
			}
			else {
				throw string("Invalid Input for High and Low. High must be greater than Low.");
			}
		}//end try

		catch (string err) {
			cout << err << endl;				//Print thrown string from try block
			cin.clear();						//Clear the stream for the next iteration
			cin.ignore(1, '\n');				//Ignore anything left behind after the clear
		}//end catch

		TerminationCheck:						//Label for the 'goto' to direct the system where to go when reached
		//Prompt user for program termination
		cout << endl;
		cout << "Try again with new index numbers for array? ('y' or 'n')" << endl;
		cin >> Continue;

		if (Continue == 'y' || Continue == 'Y') {
			cout << endl;							//For spacing purposes
			object.~recFun();						//Call destructor to reset values for next iteration
			cin.clear();							//Clear the stream for the next iteration
			cin.ignore(1, '\n');					//Ignore anything left behind after the clear
			low = 99;								//Just in case of infinite loop I set this to a value that will fail immediately(fail safe to a fail safe) 
			high = 0;								//Same here (fail safe to a fail safe)
		}

		else {
			boolean = false;						//Change while condition to end loop
			object.~recFun();						//Call destructor for program end
		}
	}//end while
	return 0;
}//end main
#pragma once
#include <iostream>
using namespace std;

class recFun {
private:
	//Fields
	int length = 100;
	int low, high;

public:
	//Default Constructor
	recFun() {
		low = 0;
		high = 99;
	}

	//Parameterized Constructor
	recFun(int low, int high) {
		this->low = low;
		this->high = high;
	}

	//Destructor
	~recFun() {
		low = 99;
		high = 0;
	}

	//Accessors
	int getLength() {
		return length;
	}
	int getLow() {
		return low;
	}
	int getHigh() {
		return high;
	}

	//Mutators
	void setLength(int length) {
		this->length = length;
	}
	void setLow(int low) {
		this->low = low;
	}
	void setHigh(int high) {
		this->high = high;
	}

	//Recursive method to print the array
	void recPrintArray(int intArray[], int element) {

		//Base case to end recursive method
		if (element == length) {
			return;
		}

		cout << element << ": " << intArray[element] << endl;		//Print the current index plus 1 for 1-100 then
																	//print the current element at that index

		recPrintArray(intArray, element + 1);						//recursive call, increase index by 1
	}

	//Recursive method to fill the array
	void recFillArray(int intArray[], int element) {

		//Base case to end recursion
		if (element == length) {
			return;
		}

		intArray[element] = element + 1;			//Stores the value 1 at index 0. And so on with each iteration

		recFillArray(intArray, element + 1);		//Recursive call with the updated value of length + 1

	}//end fillArray

	//Recursive method to reverse elements based on indices
	void recReverse(int intArray[], int low, int high) {
		//Base Case to end recursive method
		if (low >= high) {
			return;
		}

		//Swap values, basically using the selection sort method to swap the elements at the current indices
		int temp;
		temp = intArray[low];					//temp stores the element at the current low index
		intArray[low] = intArray[high];			//take the high index and store the element in the low index
		intArray[high] = temp;					//use temp to store the low index value in the high index position

		recReverse(intArray, low + 1, high - 1);	//Recursive call, increase low by +1 and decrease high by -1
	}//end recReverse

	//Boolean to check the low index is within the correct range
	bool LowCheck() {
		if (low >= 0 && low <= 98) {
			return true;
		}
		else {
			return false;
		}
	}

	//Boolean to check the high index is within the correct range
	bool HighCheck() {
		if (high >= 1 && high <= 99) {
			return true;
		}
		else {
			return false;
		}
	}

	//Boolean to check high index is greater than low index
	bool LowToHigh() {
		if (low < high) {
			return true;
		}
		else {
			return false;
		}
	}
};
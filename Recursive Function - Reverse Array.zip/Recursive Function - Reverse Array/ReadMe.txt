Program Name: Recursive Reversal
Author: Michael Krause
Last Update: 3/26/2022
Purpose: To allow the user to decide upon the size of the array and then have them choose a low index and a
high index contained within the array. The program then uses recursion to reverse the order of the elements
in between the indecies chosen by the user and print the results. 

:::Problem Statement:::

a) Write a recursive function to implement the recursive algorithm of Excercise 16 in the new book. 
(reverse the the elements of an array between two indices).

b) Also write a program to test your function.

Suppose intArray is an array of integers, and length is the number of elements in the array.

Variable "low" and "high" are two integers such that 0<=low<length, 0<=high<length and low<high.  
The variables low and high indicate two indices in the array.  Implement a recursive algorithm which reverse 
the elements in intArray between low and high.

:::My Solution:::

:::Class recFun:::
I used recursive methods to do all the iteration of a for loop. The easiest way to do this was to build the
program with for loops, for proof of concept, and then keep the build and use recursion where ever I had a
for loop doing something. 

To reverse the elements of the array the recReverse takes the array with the low and high index. Essentially
is doing a selection sort but without the sort to swap the values of the current high and low index. The next
recursive call of recReverse happens and the low index is incremented (+1) and the high index is decremented
(-1) to swap the next two values. The base case checks if low has surpassed high or if low equals high like
for even numbers. 

To fill the array with numbers recFillArray takes in the array declared from main with the starting index of
0. The number 1 is then inserted at position zero and the another recursive call is performed by sending the
array and the number incremented (+1) to insert the next number in the next index of the array. The base case
allows the method to run until the element equals the size of the array. The array has been getting updated
with each recursion call so I don't need to return anything. It just needs to return to the main program.

To print the array recPrintArray is called and essentially does the exact same thing as recFillArray except
print the current element instead of store a number in the current element.

:::Main:::
For my program I instantiated an array of 100 integers values and assigned them to the int array in sequential 
order from 1 to 100. I used a while loop to run through the program until the user decides to terminate the 
program. The user is asked to enter a number for the two indices and the program will reverse the order of 
elements within the array between the indicated indices. 

I changed it up a little from the prompt and when the user enters a number for the low index the value is
tested to make sure it's within the proper range. Because the high index maxes out at 99 the max range for the 
low index is 98. And because the low index bottoms out at 0 the lowest value for the high index is 1. When the 
user enters a value for the low index I used a boolean method from the object class to check that it's within
the range of 0-98 before proceeding. When the user enters a value for the high index I have a boolean method
to check the high index is within the range of 1-99 before proceeding. If the test for low and the test for 
high come back true I then run a boolean method to check that the high index is greater than the low index. 
Each check is within a try catch block to catch and report back to the user the location the error took place. 

When the user enters valid inputs for the high and low index the program calls the recursive methods stored
withing the object to fill the array with numbers in sequential order. The next recursive method called sends
the array with the high and low indices to reverse the order of elements between the choosen indices. Once the
reversal method has finished the final recursive method prints the current order of the array back to the user.

Once the array has been printed to the console the user is asked to continue or terminate the program.
Title: Binary 2 Decimal with Stacks and recursion!!
Author: Michael Krause
Last Update: 2/16/2022
Purpose: To convert any binary number into a decimal value using stacks and recursive summation to find the decimal value.

Objective:
Complete Program: The Programming Example, Converting a Number from Binary to Decimal, in Chapter 15, uses recursion to convert a 
binary number into an equivalent decimal number. Write a program that uses a stack to convert a binary number into an equivalent 
decimal number.

My Implementation:
Class:
The class holds a string value of the binary number to go through it one char at a time. This makes it easier to ensure the number is 
a binary number and allows traversal of the string one char at a time to find the correct sum in converting to a decimal number. Includes
a default constructor, a parameterized constructor, and a destructor to reset the values after each test. Accessors and mutators for the
fields created and the toString method outputs the data from the fields for the user.

Method to convert from Binary to Decimal:
As soon as the method is called it enters a for loop that checks each value from the binary string to ensure it's actually a binary number.
If an illegal value is found it will print a message to the user for invalid entry and break from the for loop. A value is assigned to a
variable if that happens that will ensure the rest of the method doesn't run and the program returns to main to reset the values and start
the next test.

Method for a boolean check of the binary expression:
Method takes in an int value from the for loop described above. The int value determines the char value from the string that we are
interested in checking if it's '1' or '0'. If so it returns true, else returns false and the program will break from the for loop. 

Method to return the character from the binary string:
Basically an Accessor to the Binary value. But it takes in an int value from the for loop described above to return the proper char.

Method for recursive summation of the binary to decimal value:
The first if statement is there to stop any infinite loops from using recursion; similar to a conditional for a while or for loop. The
if statement checks if the stack is empty, so end, or if the exponent value is becomes equal to or greater than the size of the stack.
Which ever comes first but they should always hit at the same time. The second if statement is only interested if the value is '1'. If
so it will use the current placement of the value and take 2^(that placement as an exponent) and add it to the running decimal value.
Pop the value on the top of the stack and increase the power value by 1. The power value needs to increment instead of decrement because
the stack is giving the binary value in the opposite order it was entered. The return statement returns the change in values back to the
conversion method and calls the same method again with the updated values. Without the return statement the decimal value would be output
as 0. The final else statement only runs if a '1' is not detected. Since the for loop checks for validation of a binary number, it must be
a 0. Since that is the case we don't need to update the decimal value, we just need to pop the top value from the stack, increase the power
value by 1 and return the values for the next recursion. 

Main:
Declare the object and stack to be used in the program. Each of the 5 test cases will set the binary value, call the conversion method
from the object, and then call the destructor to reset all values for the next test case.








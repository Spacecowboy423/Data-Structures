/*
Title: Binary 2 Decimal with Stacks and recursion!!
Author: Michael Krause
Last Update: 2/16/2022
Purpose: To convert any binary number into a decimal value using stacks and recursive summation to find the decimal value. 
*/

#include <iostream>
#include <stack>
using namespace std;

class BinaryNumber {
private:
    //Fields
    string Binary;
    int Decimal;

public:
    //Default Constructor
    BinaryNumber() {
        Binary = "0";
        Decimal = 0;
    }

    //Parameterized Constructor
    BinaryNumber(string Binary) {
        this->Binary = Binary;
        Decimal = 0;
    }

    //Destructor
    ~BinaryNumber() {
        setBinary("");
        setDecimal(0);
    }

    //Accessors
    string getBinary() {
        return Binary;
    }
    int getDecimal() {
        return Decimal;
    }

    //Mutators
    void setBinary(string Binary) {
        this->Binary = Binary;
    }
    void setDecimal(int Decimal) {
        this->Decimal = Decimal;
    }
    //toString
    void toString() {
        cout << "Binary Number: " << getBinary() << endl;
        cout << "Decimal Number: " << getDecimal() << endl;
        cout << endl;
    }

    //Methods
    void Bi2Dec(stack<char> Number) {
        
        //Check string is only 1 or 0
        int breakloop = 0;
        for (int i = 0; i < getBinary().length(); i++) {
            if (BinaryCheck(getBinaryChar(i))) {
                Number.push(getBinaryChar(i));
            }
            else {
                cout << "Illegal entry made, " << getBinaryChar(i) << " is not a binary digit." << endl;
                breakloop++;
                break;
            }
        }
        //End program if wrong entry found
        if (breakloop == 0) {
            //Declare and initialize power value for the recursive method. Sends the stack, size of the stack, and the power value
            //to the method. What is returned from that method is used to set the Decimal value of the object. Then toString
            //outputs the results back to the user
            int power = 0;
            setDecimal(RecursiveSum(Number, Number.size() - 1, power));
            toString();
        }
        else {
            cout << "Reaching here this means illegal entry and loop is ending." << endl;
        }

    }

    bool BinaryCheck(char check) {
        //If char is a 1 or a 0 return true, else return false
        if (check == '1' || check == '0') {
            return true;
        }
        else {
            return false;
        }
    }

    char getBinaryChar(int i) {
        return Binary[i];
    }

    int RecursiveSum(stack<char> Number, int size, int power) {
        //If statement is here to stop any infinite loops. Once the stack is empty or the power value is no greater than the original
        //size of the stack the recursive methods will end and return the decimal value.
        if (Number.empty() || size < power){
            return getDecimal();
        }
        //If the char number on the top of the stack is a '1' then this statement will grab the current decimal value and add it to the
        //calculated value of 2^(current power). The exponent is determined by the place value of the '1'. If it's in the tenth value then
        //the value will calculate 2^10, add it to the current decimal value and then store it as the new decimal value. Pop the top value 
        //from the stack, increase the power value by 1 since the stack is giving us our binary number in the opposite order. 
        else if (Number.top() == '1') {
            setDecimal(getDecimal() + pow(2, power));
            Number.pop();
            power++;
            return RecursiveSum(Number, size, power);
        }
        //If the char number is not a '1' then pop it from the top of the stack and increase the power value by 1 for the next number. Return
        //the recursive method to update the decimal value in the main conversion method and then calls the recursive method 
        //again with the updated values from the first run through. Without the return statment the final value would just be 0. 
        else {
            Number.pop();
            power++;
            return RecursiveSum(Number, size, power);
        }
    }
};
//
//Main
//
int main() {

    //Declare variable
    BinaryNumber Bi;
    stack<char> Number;

    //Initialize Binary Number
    Bi.setBinary("1001");
    //Convert
    Bi.Bi2Dec(Number);
    //Call Destructor
    Bi.~BinaryNumber();
    
    //Test 2
    Bi.setBinary("01001011010");
    Bi.Bi2Dec(Number);
    Bi.~BinaryNumber();

    //Test 3
    Bi.setBinary("10011001");
    Bi.Bi2Dec(Number);
    Bi.~BinaryNumber();

    //Test 4
    Bi.setBinary("1010100110");
    Bi.Bi2Dec(Number);
    Bi.~BinaryNumber();

    //Test 5
    Bi.setBinary("0100100101");
    Bi.Bi2Dec(Number);
    Bi.~BinaryNumber();

    //End Program
    return 0;
}

//For testing purposes
/*
//Recursion function example
int recursivesum(int m, int n) {
    if (m == n) {
        return m;
    }
    return m + recursivesum(m + 1, n);
}
    //Main
    //Recursive sumation example (this was just a test case: remember to comment out)
    int m = 1, n = 3;
    cout << "Sum = " << recursivesum(m, n) << endl;
        
        //Conversion Loop
        //As long as all characters are a '1' or '0'
        if (breakloop == 0) {
            cout << "This should only print if all chars are 1 and 0." << endl;
            int size = Number.size() - 1;
            for (int i = 0; i <= size; i++) {
                cout << Number.size() - 1 << endl;
                cout << "Current size: " << i << endl;
                cout << "Current power value: " << pow(2, i) << endl;
                cout << "Number at top of stack: " << Number.top() << endl;
                if (Number.top() == '1') {
                    setDecimal(getDecimal() + pow(2, i));
                    Number.pop();
                }
                else {
                    Number.pop();
                }
            }
            toString();
*/
/*
Program Name: Traversing Digital Graph
Author: Michael Krause
Last Update: 4/21/2022
Purpose: Using a linked lists to create a graph and adjaceny list to store and print information. Information can be printed as the
adjaceny, breadth first, or depth first traversal.
*/

//depth
//0, 2, 1, 8, 4, 3, 7, 5, 6

//breadth
//0, 2, 4, 1, 3, 8, 7, 5, 6

//vertex 3
//3, 7, 5, 6, 0, 2, 1, 8, 4

#include <iostream>
using namespace std;
#include "GraphADT.h"

int main() {

	graphType graph(9);

	graph.createGraph();
	cout << endl;

	cout << "Print Graph:" << endl;
	graph.printGraph();
	cout << endl;

	cout << "Print depth first: ";
	graph.depthFirstTraversal();
	cout << endl;

	cout << "Print breadth first: ";
	graph.breadthFirstTraversal();
	cout << endl;

	cout << "Print From Vertex: ";
	graph.dftAtVertex(3);
	cout << endl;

	cout << "Clear Graph...";
	graph.clearGraph();
	cout << "done.";
	cout << endl;
}

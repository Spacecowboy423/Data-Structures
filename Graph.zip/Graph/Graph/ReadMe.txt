Program Name: Traversing Digital Graph
Author: Michael Krause
Last Update: 4/21/2022
Purpose: Using a linked lists to create a graph and adjaceny list to store and print information. Information can be printed as the
adjaceny, breadth first, or depth first traversal.

Problem Statement:
Programming Exercise 1: Write a program that outputs the nodes of a graph in a depth-first traversal.
Programming Exercise 2: Write a program that outputs the nodes of a graph in a breadth-first traversal.

My Execution:
The graph is created from numbers that do not exceed the value of the highest index. The graph is from 0-9 and no number in the graph 
exceeds the value 9. This ensures that when the loop runs to check if a vertex has been visited it does not try to check a value of 
52 which would in turn exceed the size of the visited[] array. At start the program declares a graph and sets the size by the number of
vertices in the graph, in this case 9 is size and is set manually. This creates an unorderedLinkList of size 9. The create graph method
is called and uses file numbers.txt to find the first number on a line, the index, and then links the rests of the numbers from the file
as adjacent and creates a link from the index to the last number before moving on to the next line. With the graph now made the program
prints the graph created in adjacency form. I then use the depth first traversal, breadth first traversal, and depth first at the specified
index of 3. The program traverses the same graph each time but prints the nodes in order depedning on the traversal method.
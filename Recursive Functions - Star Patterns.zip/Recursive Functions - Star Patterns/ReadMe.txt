Program Name: Star-Maker
Author: Michael Krause
Last Update: 3/26/2022
Purpose: Have the user input a non-negative number and print a descending then ascending star pattern back to
the user using recursion.

Problem Statement:
a) Write a recursive function which takes a parameter of a nonnegative integer and generates a pattern of stars 
as shown below.  If the input number was 4 it would look like this.

****
***
**
*
*
**
***
****

b) Also, write a program that prompts the user to enter the number of lines in the pattern and uses the recursive 
function to generate the pattern.  Use at least three different test cases.

My Solution:
Class StarMaker:
I included the recursive method as part of the object as the toString. The base case in the recursive call checks
when Lines is less than or equal to 0 to begin the process of printing the star pattern in ascending order. When
the program enters the toString it takes the current value and send it to the stars() function to print the current
line of the pattern. So if Lines is 5, stars will print 5 stars before executing the recursive call to come back in
with the value changed to 4. So it prints the pattern in descending order from 5 to 1. When Lines reaches 0 the 
base case has been met and the program begins executing the remaing code from each previous recursion call. Because 
every time a recursion happens the system creates another function with all the variables and parameters there is
code that was not yet executed contained in each recursion. With each recursion call having remaining lines of code
to execute, it does so in the opposite order printing each line of the pattern from 1 to 5. It goes in print 5 to 1
then it comes out printing 1 to 5 with the recursive call acting as the pivot point for the star pattern.

Method Stars:
Simple for loop to print the number of stars for each line.

Main:
I created a program that prompt the user to enter a number for the number of lines in the pattern and then used
a try catch block to ensure a non-negative number was entered. I used a float as the user input in case the user
enters a decimal instead of an integer value. I then immediately cast the number back to itself as an int before
setting the object variable to the users entry and calling the recursive function to print the star pattern.

I used a while loop to keep the program going until the user decides to terminate. 


#pragma once
#include <iostream>
using namespace std;

class StarMaker {
private:
	int Lines;

public:
	//Default Constructor
	StarMaker() {
		Lines = 0;
	}

	//Paramterized Constructor
	StarMaker(int Lines) {
		this->Lines = Lines;
	}

	//Destructor
	~StarMaker() {
		Lines = 0;
	}

	//Accessor
	int getLines() {
		return Lines;
	}

	//Mutator
	void setLines(int Lines) {
		this->Lines = Lines;
	}

	//toString
	void printLines(int Lines) {
		//base condition
		if (Lines <= 0) {
			return;
		}

		stars(Lines);						//Print number of '*' in descending order (one line at a time)

		printLines(Lines - 1);				//Direct recursive call

		stars(Lines);						//Print number of '*' in ascending order (one line at a time)
	}//end printLines

	//Print Star Pattern
	void stars(int Lines) {
		//Loop prints the current line of the pattern
		for (int i = 0; i < Lines; i++) {
			cout << "*";
		}
		cout << endl;
	}
};
/*
Program Name: Star-Maker
Author: Michael Krause
Last Update: 3/26/2022
Purpose: Have the user input a non-negative number and print a descending then ascending star pattern back to
the user using recursion.
*/

#include "StarMaker.h"

int main(){

	//Declare Object
	StarMaker Stars;

	//Declare Program Variables
	enum {Reset};					//Reset variables
	char Continue;					//User input for program termination
	float Lines;					//User input for size of pattern
	bool boolean = true;			//Intialize Bool
	
	//Welcome Prompt
	cout << "This program will take in a number by the user and print a star pattern to the console." << endl;
	cout << "Based on the user input determines the length of the descending and ascending star pattern." << endl;
	cout << endl;

	while (boolean) {
		//Prompt user to enter number
		cout << "Enter number of lines in the pattern." << endl;
		cin >> Lines;
		cout << endl;

		try {
			if (Lines >= 0) {							//Check input is non-negative
				Lines = (int) Lines;					//Cast Lines back to itself as an int in case user entered decimal number
				Stars.setLines(Lines);					//Set object variable
				Stars.printLines(Stars.getLines());		//Run objects recursive method to print the star pattern
			}
			else {
				throw(string("Invalid Entry.\nPlease enter an non-negative number only."));
			}
		}//end try

		catch (string err) {
			cout << err << endl;
			cin.clear();
			cin.ignore(1, '\n');
		}//end catch

		//Prompt User to Continue Program
		cout << endl;
		cout << "Try again with a new number? ('y' or 'n')" << endl;
		cin >> Continue;
		cout << endl;

		if (Continue == 'y' || Continue == 'Y') {	//Check for program termination
			Lines = Reset;							//Reset Program variable for next iteration
			Stars.~StarMaker();						//Call destructor for next iteration
		}

		else {
			boolean = false;						//Change the while condition to false to end program
			break;
		}
	}//end while
	return 0;
}//end main
#include "avlTreeType.h"

template <>
void avlTreeType<int>::rotateLeft(AVLNode<int>*& root) {
	AVLNode<int>* p; //pointer to the root of the right subtree of root

	if (root == nullptr) {
		std::cout << "Error in the tree" << std::endl;
	}

	else if (root->rLink == nullptr) {
		std::cout << "Error in the tree: No right subtree to rotate." << std::endl;
	}

	else {
		p = root->rLink;
		root->rLink = p->lLink; //the left subtree of p becomes the right subtree of root
		p->lLink = root;
		root = p; //make p the new root node
	}
}//rotateLeft

template <>
void avlTreeType<int>::rotateRight(AVLNode<int>*& root) {
	AVLNode<int>* p; //pointer to the root of the left subtree of root

	if (root == nullptr) {
		std::cout << "Error in the tree" << std::endl;
	}

	else if (root->lLink == nullptr) {
		std::cout << "Error in the tree: No left subtree to rotate." << std::endl;
	}

	else {
		p = root->lLink;
		root->lLink = p->rLink; //the right subtree of p becomes
		//the left subtree of root
		p->rLink = root;
		root = p; //make p the new root node
	}
}//end rotateRight

template <>
void avlTreeType<int>::balanceLeft(AVLNode<int>*& root) {
	AVLNode<int>* p;
	AVLNode<int>* w;
	p = root->lLink; //p points to the left subtree of root

	switch (p->bfactor) {
	case -1:
		root->bfactor = 0;
		p->bfactor = 0;
		rotateRight(root);
		break;

	case 0:
		std::cout << "Error: Cannot balance from the left." << std::endl;
		break;

	case 1:
		w = p->rLink;
		switch (w->bfactor) {		//adjust the balance factors
		case -1:
			root->bfactor = 1;
			p->bfactor = 0;
			break;

		case 0:
			root->bfactor = 0;
			p->bfactor = 0;
			break;
	
		case 1:
			root->bfactor = 0;
			p->bfactor = -1;
		}//end switch
		
		w->bfactor = 0;
		rotateLeft(p);
		root->lLink = p;
		rotateRight(root);
	}//end switch;
}//end balanceFromLeft

template <>
void avlTreeType<int>::balanceRight(AVLNode<int>*& root) {
	AVLNode<int>* p;
	AVLNode<int>* w;
	p = root->rLink;				//p points to the left subtree of root

	switch (p->bfactor) {
	case -1:
		w = p->lLink;
		switch (w->bfactor) {		//adjust the balance factors
		case -1:
			root->bfactor = 0;
			p->bfactor = 1;
			break;

		case 0:
			root->bfactor = 0;
			p->bfactor = 0;
			break;

		case 1:
			root->bfactor = -1;
			p->bfactor = 0;
		}//end switch

		w->bfactor = 0;
		rotateRight(p);
		root->rLink = p;
		rotateLeft(root);
		break;

	case 0:
		std::cout << "Error: Cannot balance from the left." << std::endl;
		break;

	case 1:
		root->bfactor = 0;
		p->bfactor = 0;
		rotateLeft(root);
	}//end switch;
}//end balanceFromRight
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template <>
void avlTreeType<int>::insertIntoAVL(AVLNode<int>*& root, AVLNode<int>* newNode, bool& isTaller) {
	if (root == nullptr) {
		root = newNode;
		isTaller = true;
	}
	
	else if (root->info == newNode->info) {
		std::cout << "No duplicates are allowed." << std::endl;
	}
	
	else if (root->info > newNode->info) {			//newItem goes in the left subtree
		insertIntoAVL(root->lLink, newNode, isTaller);
		
		if (isTaller) {				//after insertion, the subtree grew in height
			switch (root->bfactor) {
			case -1:
				balanceLeft(root);
				isTaller = false;
				break;

			case 0:
				root->bfactor = -1;
				isTaller = true;
				break;

			case 1:
				root->bfactor = 0;
				isTaller = false;
			}//end switch
		}//end if
	}//end else if

	else {
		insertIntoAVL(root->rLink, newNode, isTaller);

		if (isTaller) { //after insertion, the subtree grew in height
			switch (root->bfactor) {
			case -1:
				root->bfactor = 0;
				isTaller = false;
				break;

			case 0:
				root->bfactor = 1;
				isTaller = true;
				break;

			case 1:
				balanceRight(root);
				isTaller = false;
			}//end switch
		}//end if
	}//end else
}//insertIntoAVL
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template <>
void avlTreeType<int>::insert(const int& newItem) {
	bool isTaller = false;
	AVLNode<int>* newNode;

	newNode = new AVLNode<int>;
	newNode->info = newItem;
	newNode->bfactor = 0;
	newNode->lLink = nullptr;
	newNode->rLink = nullptr;

	insertIntoAVL(root, newNode, isTaller);
}

template <>
void avlTreeType<int>::inorderTraversal() const {
	inorder(root);
}//end inorderTraversal

template <>
void avlTreeType<int>::inorder(AVLNode<int>* p) const {
	if (p != nullptr) {
		inorder(p->lLink);
		std::cout << p->info << " ";
		inorder(p->rLink);
	}
}//end inorder

template <>
void avlTreeType<int>::preorderTraversal() const {
	preorder(root);
}//end preorderTraversal

template <>
void avlTreeType<int>::preorder(AVLNode<int>* p) const {
	if (p != nullptr) {
		std::cout << p->info << " ";
		preorder(p->lLink);
		preorder(p->rLink);
	}
}//end preorder

template <>
void avlTreeType<int>::postorderTraversal() const {
	postorder(root);
}//end postorderTraversal

template <>
void avlTreeType<int>::postorder(AVLNode<int>* p) const {
	if (p != nullptr) {
		postorder(p->lLink);
		postorder(p->rLink);
		std::cout << p->info << " ";
	}
}//end postorder

template <>
bool avlTreeType<int>::isEmpty() const {
	return (root == nullptr);
}//end isEmpty

template <>
avlTreeType<int>::avlTreeType() {
	root = nullptr;
}//end avlTreeType

template<>
avlTreeType<int>::~avlTreeType() {
	destroy(root);
}//end ~avlTreeType

template <>
void avlTreeType<int>::destroyTree() {
	destroy(root);
}//end destroyTree

template <>
void avlTreeType<int>::destroy(AVLNode<int>*& p) {
	if (p != nullptr) {
		destroy(p->lLink);
		destroy(p->rLink);
		delete p;
		p = nullptr;
	}
}//end destroy

template <>
int avlTreeType<int>::treeHeight() const {
	return height(root);
}//end treeheight

template <>
int avlTreeType<int>::height(AVLNode<int>* p) const {
	if (p == nullptr) {
		return 0;
	}
	else {
		return 1 + max(height(p->lLink), height(p->rLink));
	}
}//end height

template <>
int avlTreeType<int>::max(int x, int y) const {
	return (x > y) ? x : y;
}//end max

///////////////////////////////
template<>
int avlTreeType<int>::treeNodeCount() const {
	return nodeCount(root);
}//end treeNodeCount

template<>
int avlTreeType<int>::treeLeavesCount() const {
	return leavesCount(root);
}//end treeLeavesCount

template<>
int avlTreeType<int>::singleParentCount() const {
	return singleParent(root);
}

template<>
int avlTreeType<int>::nodeCount(AVLNode<int>* p) const {
	//base case
	if (p == nullptr) {
		return 0;		//return 0 if current node is empty
	}
	else {
		return (nodeCount(p->lLink) + 1 + nodeCount(p->rLink));		//direct recursive call to count all the nodes in the tree
	}
}//end nodeCount

template<>
int avlTreeType<int>::leavesCount(AVLNode<int>* p) const {
	//base case
	if (p == nullptr) {
		return 0;		//return 0 if current node is empty
	}
	else if (p->lLink == nullptr && p->rLink == nullptr) {
		return 1;		//return 1 to count the leaf node with no children attached
	}
	else {
		return leavesCount(p->lLink) + leavesCount(p->rLink);		//direct recursive call to find leaf nodes
	}
}//end leavesCount

template<>
int avlTreeType<int>::singleParent(AVLNode<int>* p) const {
	//base case
	if (p == nullptr) {		//check the node is not empty
		return 0;		//return 0 if current node is empty
	}
	if (p->lLink == nullptr && p->rLink != nullptr) {		//check if left is empty and right is not
		return 1 + singleParent(p->rLink);		//return 1 on this recursive call for the left node single parent and continue to the right node
	}
	if (p->rLink == nullptr && p->lLink != nullptr) {		//checks if right is empty and left is not
		return 1 + singleParent(p->lLink);		//return 1 on this recursive call for the right node single parent and continue to the left node
	}
	else {
		return singleParent(p->lLink) + singleParent(p->rLink);		//direct recursive call for left and right side if neither is empty
	}
}//end singleParent


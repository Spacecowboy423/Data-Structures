/*
Program Name: AVL Binary Tree Insertion
Author: Michael Krause
Last Update: 04/08/2022
Purpose: To use an AVL tree to insert data properly to keep the tree balanced using the height from the root node to the end of each subtree. When one
subtree gets out of balance the tree needs to be rotated in the proper direction and determine if more rotations are needed until the tree is balanced.
*/

#include "avlTreeType.h"
#include <string>

bool isDigit(std::string userInput) {
    //Check input is an int
    for (int i = 0; i < userInput.length(); i++) {
        if (userInput[i] < '0' || userInput[i] > '9') {
            return false;
        }
    }
    return true;
}//end isDigit

int main() {
    avlTreeType<int> avlTree;

    /* Constructing tree given in the above figure */
    avlTree.insert(10);
    avlTree.insert(20);
    avlTree.insert(30);
    avlTree.insert(40);
    avlTree.insert(50);
    avlTree.insert(25);

    std::cout << "Inorder traversal of the constructed AVL tree is \n";
    avlTree.inorderTraversal();
    std::cout << std::endl;

    std::cout << "Preorder traversal of the constructed AVL tree is \n";
    avlTree.preorderTraversal();
    std::cout << std::endl;

    std::cout << "Postorder traversal of the constructed AVL tree is \n";
    avlTree.postorderTraversal();
    std::cout << std::endl;

    std::cout << "The tree height: " << avlTree.treeHeight() << std::endl;			//Print the height of the tree - longest path from root to some leaf
    std::cout << "The tree Leaves: " << avlTree.treeLeavesCount() << std::endl;	//Print the number of leaf nodes in the tree - no children nodes
    std::cout << "The tree Nodes: " << avlTree.treeNodeCount() << std::endl;		//Print the number of nodes in the tree
    std::cout << "The number of Single Parent Nodes is: " << avlTree.singleParentCount() << std::endl;		//Print the single parent count of the tree to the user - number of parent nodes with only one child node

    avlTree.destroyTree();

                                    			//Declare second object of type int
    int element;								//Declare program variable for element insert
    std::string userInput;							//Declare program variable for user input
    bool boolean = true;						//Declare and initialize boolean for main program loop

    //Prompt the user with the proper input needed
    std::cout << "Enter as may elements as you would like. Once finished enter 'n' to end loop." << std::endl;

    while (boolean) {
        try {
            //Prompt the user to enter an input
            std::cout << "Enter an element for input: ";
            std::cin >> userInput;

            //Check input for loop end condition
            if (userInput == "n") {
                boolean = false;
                continue;
            }
            if (isDigit(userInput)) {
                element = stoi(userInput);	//Convert the input values from string to int (supported on c++11 and newer)
                avlTree.insert(element);	//insert the element into the binary tree
            }
            else {
                throw std::string("Invalid Entry: Only input integer values.");	//if digit check returns false error string is thrown into the input stream
            }
        }

        catch (std::string err) {		//error thrown in input stream is caught
            std::cout << std::endl;			//for spacing purposes on output
            std::cout << err << std::endl;	//print error message to console
            std::cin.clear();			//clear the stream after the message has been printed
            std::cin.ignore(1, '\n');	//ignore anything left behind after clear
            std::cout << std::endl;			//for spacing purposes on output
        }
    }

    std::cout << "Inorder traversal of the constructed AVL tree is \n";
    avlTree.inorderTraversal();
    std::cout << std::endl;

    std::cout << "Preorder traversal of the constructed AVL tree is \n";
    avlTree.preorderTraversal();
    std::cout << std::endl;

    std::cout << "Postorder traversal of the constructed AVL tree is \n";
    avlTree.postorderTraversal();
    std::cout << std::endl;

    std::cout << "The tree height: " << avlTree.treeHeight() << std::endl;			//Print the height of the tree - longest path from root to some leaf
    std::cout << "The tree Leaves: " << avlTree.treeLeavesCount() << std::endl;	//Print the number of leaf nodes in the tree - no children nodes
    std::cout << "The tree Nodes: " << avlTree.treeNodeCount() << std::endl;		//Print the number of nodes in the tree
    std::cout << "The number of Single Parent Nodes is: " << avlTree.singleParentCount() << std::endl;		//Print the single parent count of the tree to the user - number of parent nodes with only one child node

    avlTree.destroyTree();

    return 0;
}

/*
        10
          \
           20
             \
              30     rotate left from 10

        20
        /\
      10  30
            \
             40
               \
                50  rotate left from 20

            30
            /\
          20  40
          /     \
        10       50    insert 25

             30
             /\
            20 40
            /\   \
          10  25  50
*/


/* The constructed AVL Tree should be
         30
        /  \
       20   40
       /\     \
     10  25    50

     Inorder: 10 20 25 30 40 50
     preorder: 30 20 10 25 40 50
     postorder: 10 25 20 50 40 30

     My tree: 10 20 30 40 50 25                       10                10
     Inorder: 10 20 25 30 40 50                      /  \              /  \
     preorder: 10 20 30 25 40 50                   20    40          40    20
     postorder: 25 50 40 30 20 10                 /  \     \        /  \     \
                                                30    25    50    25    50    30


*/
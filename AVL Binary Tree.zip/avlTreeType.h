#pragma once
#include <iostream>
#include <string>

template <class elemType>
struct AVLNode {
    elemType info;
    AVLNode<elemType>* lLink;
    AVLNode<elemType>* rLink;
    int bfactor; //balance factor
};

template <class elemType>
class avlTreeType {
public:
    void rotateLeft(AVLNode<elemType>*& root);

    void rotateRight(AVLNode<elemType>*& root);

    void balanceLeft(AVLNode<elemType>*& root);

    void balanceRight(AVLNode<elemType>*& root);

    void insert(const int& newItem);

    void inorderTraversal() const;
    //Function to do an inorder traversal of the binary tree.
    //Postcondition: Nodes are printed in inorder sequence.

    void preorderTraversal() const;
    //Function to do a preorder traversal of the binary tree.
    //Postcondition: Nodes are printed in preorder sequence.

    void postorderTraversal() const;
    //Function to do a postorder traversal of the binary tree.
    //Postcondition: Nodes are printed in postorder sequence.

    int treeHeight() const;
    //
    int treeNodeCount() const;

    int treeLeavesCount() const;
    
    int singleParentCount() const;
    //
    bool isEmpty() const;

    void destroyTree();

    //Default Constructor
    avlTreeType();

    //Destructor
    ~avlTreeType();

protected:
    AVLNode<elemType>* root;

private:
    void insertIntoAVL(AVLNode<elemType>*& root, AVLNode<elemType>* newNode, bool& isTaller);
    
    void inorder(AVLNode<elemType>* p) const;

    void preorder(AVLNode<elemType>* p) const;

    void postorder(AVLNode<elemType>* p) const;

    int max(int x, int y) const;

    int height(AVLNode<elemType>* p) const;

    void destroy(AVLNode<elemType>*& p);
    //
    int nodeCount(AVLNode<elemType>* p) const;

    int leavesCount(AVLNode<elemType>* p) const;

    int singleParent(AVLNode<elemType>* p) const;
    //
};
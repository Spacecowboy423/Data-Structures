#pragma once
#include "unorderedLinkedList.h"
#include "linkedQueueType.h"
#include <iostream>
#include <fstream>

//***************************************************************
// Author: D.S. Malik
//
// class graphType
// This class specifies the basic operations to implement a graph.
//****************************************************************
class graphType {
public:
	bool isEmpty() const;
		//Function to determine whether the graph is empty.
		//Postcondition: Returns true if the graph is empty;
		//				 otherwise, returns false.

	void createGraph();
		//Function to create a graph.
		//Postcondition: The graph is created using the
		//				 adjacency list representation.

	void clearGraph();
		//Function to clear graph.
		//Postcondition: The memory occupied by each vertex
		//				 is deallocated.

	void printGraph() const;
		//Function to print graph.
		//Postcondition: The graph is printed.

	void depthFirstTraversal();
		//Function to perform the depth first traversal of
		//the entire graph.
		//Postcondition: The vertices of the graph are printed
		//				 using the depth first traversal algorithm.

	void dftAtVertex(int vertex);
		//Function to perform the depth first traversal of
		//the graph at a node specified by the parameter vertex.
		//Postcondition: Starting at vertex, the vertices are
		//				 printed using the depth first traversal 
		//				 algorithm.

	void breadthFirstTraversal();
		//Function to perform the breadth first traversal of
		//the entire graph.
		//Postcondition: The vertices of the graph are printed
		//				 using the breadth first traversal algorithm.
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//Method to add an edge from u-v and from v-u since graph is undirected
	void addEdge(int u, int v) {
		graph[u].insertLast(v);
		graph[v].insertLast(u);
	}//end addEdge

	//Method to remove an edge from the graph (set node info to -1)
	void rmvEdge(int u, int v);

	//Method to find a vertex of odd degree (if one) and send it to printPath to be the starting vertex
	void eulerianTraversal();

	//Recursive method to find paths from a specified vertex
	void printPath(int u);

	//Method to return number of vertices reachable from v. It does a depth first traversal to find the count
	int vertexCount(int v, bool visited[]);

	//Boolean method to check if edge u-v is a valid edge to traverse for Eulerian path
	bool isValidEdge(int u, int v);
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	graphType(int size = 0);
		//Constructor
		//Postcondition: gSize = 0; maxSize = size;
		//				 graph is an array of pointers to linked 
		//				 lists.

	~graphType();
		//Destructor
		//The storage occupied by the vertices is deallocated.

protected:
	int maxSize;						//maximum number of vertices
	int gSize;							//current number of vertices
	unorderedLinkedList<int>* graph;	//array to create adjacency lists

private:
	void dft(int v, bool visited[], int vint[]);
		//Function to perform the depth first traversal of
		//the graph at a node specified by the parameter vertex.
		//This function is used by the public member functions
		//depthFirstTraversal and dftAtVertex.
		//Postcondition: Starting at vertex, the vertices are
		//				 printed using the depth first traversal 
		//				 algorithm.
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void graphType::eulerianTraversal() {			// Find a vertex with an odd degree (edges)
	int u = 0;
	for (int i = 0; i < maxSize; i++) {		//for loop runs the max number of vertices to check each vertice
		if (graph[i].length() & 1) {		//this is cool, a single & in C++ is called a Bitwise & operator. It converts
			u = i;							//each number to its binary representation and checks the final bit is 1
			break;							//for odd or 0 for even. So since 3 = 0011 and 1 is 0001 and 2 is 0010
		}									//(0011 & 0001) evaluates to true and (0010 & 0001) evaluates to false
	}//end for

	//Print path starting from odd vertex or 0 if no odd degree vertex is found
	printPath(u);
	cout << endl;							//Once Eulerian path is done printing skip a line
}//end eulerianTraversal

void graphType::printPath(int u) {							//Find all the vertices adjacent to this vertex
	linkedListIterator<int>	graphIt;									//iterator for node
	for (graphIt = graph[u].begin(); graphIt != graph[u].end(); ++graphIt) {		//set i to the first vertex of u and run until all paths of u have been travelled
		int v = *graphIt;												//set v to the info stored in current vertex

		if (v != -1 && isValidEdge(u, v)) {						//check that v hasn't been visited and then check that u-v is a valid edge to traverse
			cout << u << "-" << v << "  ";						//print path from u - v
			rmvEdge(u, v);										//call method to mark the path from u - v as traversed (set node to -1)
			printPath(v);										//direct recursive call with current vertex to check v's paths, if no paths or a bridge return to check the next vertex of u
		}
	}//end for
}//end printPath

bool graphType::isValidEdge(int u, int v) {
	//The edge u-v is valid in one of the following two cases:
	//The first case checks if v is the only adjacent vertex of u
	int count = 0;					//Store count of adjacent vertices
	linkedListIterator<int> graphIt;
	for (graphIt = graph[u].begin(); graphIt != graph[u].end(); ++graphIt) {
		if (*graphIt != -1) {				//if i = -1 then the path has been travelled so, if path hasn't been travelled increase count by 1
			count++;
		}
	}//end for
	if (count == 1) {				//if count is 1 then there is only one path to follow so return true for valid path
		return true;
	}

	//The second case is if there are multiple adjacents of u
	//If so then then find if u-v is a bridge or a valid path
	//Step 1: count of vertices reachable from u
	bool* visited;							//create boolean pointer
	visited = new bool[maxSize];			//set pointer to an array of boolean values the size of the number of vertices
	memset(visited, false, maxSize);		//build in method from iostream to update the entire array to false. memset(array, value to set each element, size of array)
	int count1 = vertexCount(u, visited);		//returns the count of vertices from vertex u and uses the visited array to update to true in vertexCount

	//Step 2: Remove edge (u, v) and after removing the edge, count vertices reachable from u
	rmvEdge(u, v);							//"remove" the edge from the graph by setting the value to -1 for both u to v and v to u since graph is undirected
	memset(visited, false, maxSize);		//reset the visited array to all false values
	int count2 = vertexCount(u, visited);		//find count (degree) of reachable vertices from u with edge removed

	//Step 3: Add the edge back to the graph
	addEdge(u, v);

	//Step 4: If count1 is greater, then edge (u, v) is a bridge so return false else return true
	return (count1 > count2) ? false : true;
}//end isValidEdge

void graphType::rmvEdge(int u, int v) {
	//Find v in the adjacency list of u and replace it with -1
	linkedListIterator<int> graphIt1;
	for (graphIt1 = graph[u].begin(); graphIt1 != graph[u].end(); ++graphIt1) {
		if (*graphIt1 == v) {
			graphIt1 = -1;
			break;
		}
	}//end for
	
	//Then find u in adjacency list of v and replace it with -1
	linkedListIterator<int> graphIt2;
	for (graphIt2 = graph[v].begin(); graphIt2 != graph[v].end(); ++graphIt2) {
		if (*graphIt2 == u) {
			graphIt2 = -1;
			break;
		}
	}//end for
}//end rmvEdge

int graphType::vertexCount(int v, bool visited[]) {
	visited[v] = true;										//Check the current node as visited
	int count = 1;											//Set count to 1 for first and/or each recursive call for total count of vertices

	linkedListIterator<int> graphIt;
	for (graphIt = graph[v].begin(); graphIt != graph[v].end(); ++graphIt) {	//set i to first vertex to begin depth first traveral of graph
		if (*graphIt != -1 && !visited[*graphIt]) {						//check vertex path is eligible and vertex has not been visited
			count += vertexCount(*graphIt, visited);					//recursive dive into eligble vertex and increase count by number of dives(paths)
		}
	}//end for
	return count;											//return count with number of paths from v
}//end vertexCount
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////From linkedListType
bool graphType::isEmpty() const {
	return (gSize == 0);
}//end isEmpty

void graphType::createGraph() {
	ifstream infile;
	//char fileName[50];
	int index;
	int vertex;
	int adjacentVertex;

	if (gSize != 0) {	//if the graph is not empty, make it empty
		clearGraph();
	}
	//cout << "Enter input file name: ";
	//cin >> fileName;
	//cout << endl;
	//infile.open(fileName);
	infile.open("numbers.txt");

	if (!infile) {
		cout << "Cannot open input file." << endl;
		return;
	}
	infile >> gSize; //get the number of vertices

	for (index = 0; index < gSize; index++) {
		infile >> vertex;
		infile >> adjacentVertex;

		while (adjacentVertex != -999) {
			graph[vertex].insertLast(adjacentVertex);
			graph[adjacentVertex].insertLast(vertex);
			infile >> adjacentVertex;
		}//end while
	}//end for
	infile.close();
}//end createGraph

void graphType::clearGraph() {
	int index;

	for (index = 0; index < gSize; index++) {
		graph[index].destroyList();
	}

	gSize = 0;
}//end clearGraph

void graphType::printGraph() const {
	for (int index = 0; index < gSize; index++) {
		cout << index << " ";
		graph[index].print();
		cout << endl;
	}//end for
	cout << endl;
} //end printGraph
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////From linkedListType

//Constructor
graphType::graphType(int size) {
	maxSize = size;										//total numbers of nodes
	gSize = 0;											//can never be more than the total of indexed agecencies
														//[0] 2 4
														//[1] 3 6 8
														//[2] 54 62 63
														//[3] 52 9 7
														//[4] 11
	graph = new unorderedLinkedList<int>[maxSize];		//total size of graph is set to maxSize
}

//Destructor
graphType::~graphType() {
	clearGraph();
}

void graphType::dft(int v, bool visited[], int vint[]) {
	int i;															//for loop iterator to traverse both vint[] and visited[]
	bool isPrinted = false;											//set each vertex to false, this is to handle dublicate values from different elements of vint[]
	for (i = 0; i < maxSize; i++) {									//for loop runs the length of vertices in the graph
		if (v == vint[i] && visited[i] == false) {					//checks the current value passed to dft is within the graph, also vint[], and that it has not been visitied
			visited[i] = true;										//if both conditions check out then change it to true to show it's been visited
			if (!isPrinted) {										//now check the 
				cout << v << " ";									//print the current vertex
				isPrinted = true;									//change the print value to true, to handle dublicate values
			}//end if
		}//end if;
	}//end for

	linkedListIterator<int> graphIt;												//create iterator for graph
	//for each vertex adjacent to v
	if (v >= 0 && v < gSize) {														//makes sure that u is never greater than gSize
		for (graphIt = graph[v].begin(); graphIt != graph[v].end(); ++graphIt) {	//graphIt is set to the first vertice of u and runs until the last adjacent vertice of u
			int w = *graphIt;														//w carries the value from (u, begin) to (u, end)
			//if (!visited[i]) {
			dft(w, visited, vint);													//recursively call the dft method with the current vertices 'w', visited[], and vint[]
			//}
		}//end for	
	}//end if
}//end dft

void graphType::depthFirstTraversal() {
	bool* visited;								//pointer to create the array to keep track of the visited vertices
	int* vint = new int[maxSize];				//pointer to array with vertices
	int i = 0;									//for loop iterator
	visited = new bool[maxSize];				//array of boolean is the same size as the number of vertices
	ifstream infile;							//infile is for the files where the graph information is
	infile.open("num.txt");						//open the file num with the graph info stored in it

	if (!infile) {								//if file cannot be opened print error message and return
		cout << "Cannot open input file." << endl;
		return;
	}//end if

	while (vint[i - 1] != -999) {				//infile runs until the end value of -999 is reached
		infile >> vint[i];						//each vertex from the file is stored into the array vint[]
		visited[i] = false;						//visited[] uses the same index as vint[] to track whether that vertex has been visited
		i++;
	}//end while
	infile.close();								//close input file

	for (int index = 0; index < gSize; index++) {	//for loop run the length of gSize
		dft(index, visited, vint);					//recursively call the depth first method and send the gSize index, visited[], and vint[]
	}//end for
} //end depthFirstTraversal

void graphType::dftAtVertex(int vertex) {
	bool* visited;								//pointer to create the array to keep track of the visited vertices
	int* vint = new int[maxSize];				//pointer to array with vertices
	int i = 0;									//for loop iterator
	visited = new bool[maxSize];				//array of boolean is the same size as the number of vertices
	ifstream infile;							//infile is for the files where the graph information is
	infile.open("num.txt");						//open the file num with the graph info stored in it

	if (!infile) {								//if file cannot be opened print error message and return
		cout << "Cannot open input file." << endl;
		return;
	}//end if

	while (vint[i - 1] != -999) {				//infile runs until the end value of -999 is reached
		infile >> vint[i];						//each vertex from the file is stored into the array vint[]
		visited[i] = false;						//visited[] uses the same index as vint[] to track whether that vertex has been visited
		i++;
	}//end while
	infile.close();								//close input file

	dft(vertex, visited, vint);					//send the vertex, all of visited[], and all of vint[]
}//end dftAtVertex

void graphType::breadthFirstTraversal() {
	linkedQueueType<int> queue;					//Declare queue from linkedQueueType of type int
	bool* visited;								//pointer to create the array to keep track of the visited vertices
	int* vint = new int[maxSize];				//pointer to array with vertices
	int i = 0;									//for loop iterator
	visited = new bool[maxSize];				//array of boolean is the same size as the number of vertices
	ifstream infile;							//infile is for the files where the graph information is
	infile.open("num.txt");						//open the file num with the graph info stored in it

	if (!infile) {								//if file cannot be opened print error message and return
		cout << "Cannot open input file." << endl;
		return;
	}//end if

	while (vint[i - 1] != -999) {				//infile runs until the end value of -999 is reached
		infile >> vint[i];						//each vertex from the file is stored into the array vint[]
		visited[i] = false;						//visited[] uses the same index as vint[] to track whether that vertex has been visited
		i++;
	}//end while
	infile.close();								//close input file

	linkedListIterator<int> graphIt;							//create iterator for graph
	for (int i = 0; i < gSize; i++) {							//main for loop runs the length of gsize 
		if (!visited[i]) {										//if index has not been visited
			queue.addQueue(vint[i]);							//add to queue
			visited[i] = true;									//change bool to show it has been visited
			cout << vint[i] << " ";								//print value

			while (!queue.isEmptyQueue()) {						//while loop runs until the queue is empty
				int u = queue.front();							//int u is used to hold the current queue front
				queue.deleteQueue();							//once queue front is grab clear the queue
				if (u >= 0 && u < gSize) {						//makes sure that u is never greater than gSize
					for (graphIt = graph[u].begin(); graphIt != graph[u].end(); ++graphIt) {	//graphIt is set to the first vertice of u and runs until the last adjacent vertice of u
						int w = *graphIt;														//w carries the value from (u, begin) to (u, end)
						for (int j = 0; j < maxSize; j++) {										//for loop runs entirely through both arrays if necessary
							if (w == vint[j] && visited[j] == false) {							//finds w between (u, begin) and (u, end) from vint[] and checks the corresponding bool value from visited[] 
								queue.addQueue(w);												//add w to the queue
								visited[j] = true;												//marks the vertex as visited in visited[] 
								cout << w << " ";												//print the vertex
								break;															//end for loop here for dublicate numbers in array.
							}//end if;
						}//end for
					}//end for
				}//end if
			}//end while
		}//end if
	}//end for
}//end breadthFirstTraversal
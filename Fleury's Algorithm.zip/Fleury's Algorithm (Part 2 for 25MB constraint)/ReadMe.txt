Program Name:
Author: Michael Krause
Last Update: 4/26/2022
Purpose: To use Fleury's algorithm to find a Eulerian Circuit or Path from the graph (adjacency list) given by numbers.txt



Problem Statement:
Create a program implementing Fleury's Algorithm

My Solution:
I needed a lot of help to get this one going and found a great source at geeksforgeeks to help me with this program. I included
a link to the site that I used and then I included the code used from the site under the link for you to look at. I walked through
the code and then repurposed it into graphADT with a lot of inline documentation for everything.

I marked out in my code where the new functions are that I needed to add to get everything to work.
	//Method to add an edge from u-v and from v-u since graph is undirected
	void addEdge(int u, int v) {}

	//Method to remove an edge from the graph (set node info to -1)
	void rmvEdge(int u, int v);

	//Method to find a vertex of odd degree (if one) and send it to printPath to be the starting vertex
	void eulerianTraversal();

	//Recursive method to find paths from a specified vertex
	void printPath(int u);

	//Method to return number of vertices reachable from v. It does a depth first traversal to find the count
	int vertexCount(int v, bool visited[]);

	//Boolean method to check if edge u-v is a valid edge to traverse for Eulerian path
	bool isValidEdge(int u, int v);
 
Created new overload operator in linkedListIterator.
	//Method to set the current node to -1 to know that edge has been visited
	void operator=(int v);

The program reads from the adjacency list in numbers.txt and then creates the edges between in node before calling the Eulerian Traversal
method. The method runs through the graph looking for a vertex with an odd numbers of paths. The first one found is considered the starting
vertex. If no odd vertex is found then the program uses the starting node 0. 

The print path method sets the iterator to the first path from vertex u and checks the vertex has not been travelled to (-1) and checks the
edge from u to vertex v is a valid edge to travel on. If everything checks out then print the traversal, remove the edge since it's been
travelled, and then recursively travel v to find any eliglbe paths before returning to u and checking the next path of u.

isValidEdge runs through the paths of for two test cases. If there is only one path from u-v then return true. But if there is more than 1
path then second case takes effect. It sets the visited array to all false and then send the array and the vertex to the vertexCount method.
vertexCount recursively runs through graph finding all valid edges of nodes that haven't been visited yet and increasing the count by 1. 
count1 stores this value. The current edge between u and v is removed from the graph. The boolean array is reset to false and the new count
of valid paths and unvisited nodes is returns to count2. The edge from u to v is then added back to the graph. At this point I reused the
regex expression from geekforgeeks for compare count1 to count2 and return true or false. If count1 is greater then count2 the current edge 
being looked at is a bridge (we don't want to cross yet because there is currently only one edge to it) so return false. But if count1 is
equal to or less than count2 then the current edge is valid to cross so return true.

This whole process repeats until the entire graph has been traversed in a Eulerian Circuit.
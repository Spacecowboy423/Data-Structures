#pragma once
//***********************************************************
// Author: D.S. Malik
//
// This class specifies the members to implement the basic
// properties of an unordered linked list. This class is
// derived from the class linkedListType.
//***********************************************************

#include "linkedListType.h"
#include <iostream>
using namespace std;

template<class Type>
class unorderedLinkedList : public linkedListType<Type> {
protected:
	nodeType<Type>* first;
	nodeType<Type>* last;
	int count;

public:
	// Default constructor, doesn't include anything for the unordered list because unordered list's nodes will be added when the insertFirst or insertLast or invoked.
	unorderedLinkedList() {
		first = nullptr;
		last = nullptr;
		count = 0;
	}

	bool search(const Type& searchItem) const;
		// Function to determine whether searchItemis in the list.
		// Postcondition: Returns true if searchItem is in the list, otherwise the value false is returned.

	void insertFirst(const Type& newItem);
		// Function to insert newItem at the beginning of the list.
		// Postcondition: first points to the new list, newItem is inserted at the beginning of the list,
		// last points to the last node in the list, and count is incremented by 1.

	void insertLast(const Type& newItem);
		// Function to insert newItem at the end of the list.
		// Postcondition: first points to the new list, newItem is inserted at the end of the list.
		// last points to the last node in the list, and count is incremented by 1.

	void deleteNode(const Type& deleteItem);
		// Function to delete deleteItem from the list.
		// Postcondition: If found, the node containing deleteItem is deleted from the list.
		// first points to the first node, last points to the last node of the updated list, and count is decremented by 1.

	///////////////////////////////////////////////////////////////////////////////////////
	void print() const;
		// Function to output the data contained in each node.
		// Postcondition: none.

	linkedListIterator<Type> begin();
		//Function to return an iterator at the beginning of the
		//linked list.
		//Postcondition: Returns an iterator such that current is set
		//				 to first.

	linkedListIterator<Type> end();
		//Function to return an iterator one element past the
		//last element of the linked list.
		//Postcondition: Returns an iterator such that current is set
		//				 to nullptr.

	int length() const;

	void destroyList();
		//Function to delete all the nodes from the list.
		//Postcondition: first = nullptr, last = nullptr, count = 0;
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////From linkedListType
template <class Type>
int unorderedLinkedList<Type>::length() const {
	return count;
}//end length

template <class Type>
linkedListIterator<Type> unorderedLinkedList<Type>::begin() {
	nodeType<Type>* temp(first);
	return temp;
}//end begin

template <class Type>
linkedListIterator<Type> unorderedLinkedList<Type>::end() {
	nodeType<Type>* temp(NULL);	//NULL
	return temp;
}//end end

template <class Type>
void unorderedLinkedList<Type>::destroyList() {
	nodeType<Type>* temp;		//pointer to deallocate the memory occupied by the node

	while (first != nullptr) {		//while there are nodes in the list
		temp = first;			//set temp to the current node
		first = first->link;	//advance first to the next node
		delete temp;			//deallocate the memory occupied by temp
	}

	last = nullptr;				//initialize last to nullptr; first has already been set to nullptr by the while loop
	count = 0;
}//end destroyList

//template<class Type>
//void unorderedLinkedList<Type>::print() const {
//	nodeType<Type>* current; // pointer to traverse the list.
//
//	current = first; // Set current do that it points to the first node.
//	int i = 0; // Needed to format the linked list's elements.
//	int numberToSkipToNewLine = 25;
//	while (current != nullptr) { // While more data to print
//		if (i == 0) {
//			std::cout << current->info << " ";
//		}
//		else {
//			if ((i % numberToSkipToNewLine) == 0) // If the element is in a position which has 12 as a factor, then the element next element will print to the next line.
//				std::cout << current->info << "\n";
//			else
//				std::cout << current->info << " ";
//		}
//
//		current = current->link;
//		i++;
//	}
//}

template <class Type>
void unorderedLinkedList<Type>::print() const {
	nodeType<Type>* current;			//pointer to traverse the list
	current = first;					//set current point to the first node

	while (current != nullptr) {			//while more data to print
		cout << current->info << " ";
		current = current->link;
	}
}//end print
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////From linkedListType

template<class Type>
bool unorderedLinkedList<Type>::search(const Type& searchItem) const {
	nodeType<Type>* current; // Pointer to traverse the list.
	bool found = false;

	current = first; // Set current to first node in the list.

	while (current != nullptr && !found) { // Search the list.
		if (current->info == searchItem) { // searchItem is found.
			found = true;
			return found; // Returns true.
		}
		else
			current = current->link; // Make current point to the next node.
	} // End of while

	return found; // Returns false.
} // End of search.

template<class Type>
void unorderedLinkedList<Type>::insertFirst(const Type& newItem) {
	nodeType<Type>* newNode; // Pointer to create the new node.
	newNode = new nodeType<Type>; // Create the new node.
	newNode->info = newItem; // Store newItem into the new node.
	newNode->link = first; // Insert new node before first.
	first = newNode; // Make first point to the actual first node.

	count++; // Increment count.

	if (last == nullptr) // if the list is empty, newNode is also the last node in the list.
		last = newNode;
} // End insertFirst

template<class Type>
void unorderedLinkedList<Type>::insertLast(const Type& newItem) {
	nodeType<Type>* newNode;			// Pointer to create the new node.
	newNode = new nodeType<Type>;		// Create the new node.
	newNode->info = newItem;			// Store newItem into the new node.
	newNode->link = nullptr;			// Make newNode point to the actual first node.

	if (first == nullptr) {				//If the list is empty, newNOde is both the first and last node.
		first = newNode;
		last = newNode;
		count++;						// increment count.
	}
	else {								// the list is not empty, insert newNode after last.
		last->link = newNode;			// Insert newNode after the last.
		last = newNode;					// Make last point to the actual last node in the list.
		count++;						// Increment count.
	}
} //end of insertLast

template<class Type>
void unorderedLinkedList<Type>::deleteNode(const Type& deleteItem) {
	nodeType<Type>* current;		// Pointer to traverse the list.
	nodeType<Type>* trailCurrent;	// Pointer just before current.
	bool found;

	if (first == nullptr) {			// Case 1: The list is empty.
		std::cout << "Cannot delete from an empty list." << std::endl;
	}
	else {
		if (first->info == deleteItem) {	// Case 2
			current = first;
			first = first->link;

			if (first == nullptr) {		// The list has only one node.
				last = nullptr;
			}
			delete current;
		}
		else {							// Search the list for the node with the given info.
			found = false;
			trailCurrent = first;		// Set trailcurrent to point to the first node.

			current = first->link;		// Set current to point to the second node.

			while (current != nullptr && !found) {
				if (current->info != deleteItem) {
					trailCurrent = current;
					current = current->link;
				}
				else {
					found = true;
				} // End of else.
			} // End of while
			if (found) { // Case 3: If found, delete the node.
				trailCurrent->link = current->link;
				count--;

				if (last == current) { // Node to be deleted was the last node.
					last = trailCurrent; // Update the value of the list.
				}
				delete current; // Delete the node from the list.
			}
			else {
				std::cout << "The item is to be deleted is not in the list." << std::endl;
			} // End of else
		} // End of else
	} // End of else
} // End of deleteNode
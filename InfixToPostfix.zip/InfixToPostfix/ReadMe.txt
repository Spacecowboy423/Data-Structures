Title: Infix to Postfix Conversion With Stack
Author: Michael Krause
Last Update: 2/15/2022
Purpose: To take a Infix expression and convert it to a Postfix expression. Uses a string to store the operands 
and the stack to hold the operators to build the proper Postfix expression. 

My Implentation:
The class I created holds a string for the Infix expression and the Postfix expression. As well as two int
variables that are used to determine the precedence of operators. There is a default constructor, parameterized 
constructor, and a destructor. I created accessor and mutators for all fields created. There are two toString methods
for each of the expressions.

Method to return the char of the infix string:
Method takes the count from the For loop during the conversion process as a parameter and uses it to return the 
proper char from the infix string

Method to convert infix to postfix:
The initial for loop runs the size of the infix expression. The first if statement checks if the char is a letter of
the alphabet, if so it adds the letter to the postfix string. The next statement checks if the char is a beginning 
or ending parantheses. If '(' the beginning parantheses is added to the stack. If a ')' is detected then the program 
will enter a while loop that will run until the beginning '(' is detected. The loop will apply the operator currently
on the top of the stack to the postfix string, pop the top plate, and then continue until '(' is detected. Due 
to precedence the parantheses are discarded and all operators added to postfix before proceeding with what may remain.
The 'else' statement will run if no letters or parantheses are detected, it can be assumed it's an operator. The while
loop controls how the operators are stacked. If the current operator from the expression is of greaster precedence then what
is currently on top of the stack then operator is added to the stack. If the operator currently on the stack is the
same precedence or greater than the operator from the expression the operators will be added to the postfix 
expression in the opposite order they were stacked. This applies the operators from the original expression into the
proper order for the postfix expression.

Method to empty the stack:
The method will add any operators left on the stack to the postfix expression. Then remove the operator from the
top of the stack before running the while loop again. Runs until stack is empty to make sure all operators have been
added and that the stack has been cleared. 

Method for Precedence:
The start of the method will set/reset the pvalues to 0 for each test, also ensures the final test doesn't pass an unsigned integer.
The method takes the current operator from infix and the current operator on top of the stack and checks each one for the
type of operator it is. Once determined the proper pvalue variable is assigned a value for precedence. Assigned values:
     Paranthesis () 1
     Add/Sub (+, -) 2
     Multiply/Divide (*, /) 3
     Exponent (^) 4
The higher the int the greater the precedence. If the precedence of pvalue2 >= pvalue1 the method will return true.
The returned true or false value is used in the conversion method described earlier. 

Method for endPrompt:
Simple method to utilize the tostring methods to print the infix and converted postfix expression to the user.

Main:
The main function declares the stack and class object. I created five test cases from the examples given in the objective.
Each test cases calls the proper methods to set the infix expression, convert to postfix and output results, and finally
calls the destructor from the class object to reset the object to a blank slate for the next test case. 





Problem:
Complete Program: (Infix to Postfix) Write a program that converts an infix expression into an equivalent postfix expression.
The rules to convert an infix expression into an equivalent postfix expression are as follows:
Suppose infx represents the infix expression and pfx represents the postfix expression. The rules to convert infx into pfx are as follows:

a. Initialize pfx to an empty expression and also initialize the stack.

b. Get the next symbol, sym, from infx.
b.1. If sym is an operand, append sym to pfx.
b.2. If sym is (, push sym into the stack.
b.3. If sym is ), pop and append all of the symbols from the stack until the most recent left parentheses. Pop and discard the left parentheses.
b.4. If sym is an operator:
b.4.1. Pop and append all of the operators from the stack to pfx that are above the most recent left parentheses and have precedence greater than or equal to sym.
b.4.2. Push sym onto the stack.

c. After processing infx, some operators might be left in the stack.  Pop and append to pfx everything from the stack.

In this program, you will consider the following (binary) arithmetic operators: +, -, *, and /. You may assume that the expressions you will process are error free.
Design a class that stores the infix and postfix strings. The class must include the following operations:
getInfix: Stores the infix expression.

showInfix: Outputs the infix expression.

showPostfix: Outputs the postfix expression.

Some other operations that you might need are as follows: convertToPostfix: Converts the infix expression into a postfix expression. The resulting postfix expression is stored in pfx.
precedence: Determines the precedence between two operators. If the first operator is of higher or equal precedence than the second operator, it returns the value true; otherwise, it returns the value false.
Include the constructors and destructors for automatic initialization and dynamic memory deallocation.

Test your program on the following expressions:
a. A + B - C;
Result: AB+C-
b. (A + B ) * C;
Result: AB+C*
c. (A + B) * (C - D);
Result: AB+CD-*
d. A + ((B + C) * (E - F) - G) / (H - I);
Result: ABC+EF/G*-H+
e. A + B * (C + D) - E / F * G + H;
Result: ABCD+*+EF/G*-H+
/*
Title: Infix to Postfix Conversion With Stack
Author: Michael Krause
Last Update: 2/15/2022
Purpose: To take a Infix expression and convert it to a Postfix expression. Uses a string to store the operands 
and the stack to hold the operators to build the proper Postfix expression. 
*/

#include <iostream>
#include <stack>
using namespace std;

class FixIt {
private:
    //Fields
    string infx, pfx;
    int pvalue1, pvalue2;

public:
    //Default Constructor
    FixIt() {
        infx = "";
        pfx = "";
        pvalue1 = 0;
        pvalue2 = 0;
    };

    //Parameterized Constructor
    FixIt(string infix) {
        this->infx = infix;
        pfx = "";
        pvalue1 = 0;
        pvalue2 = 0;
    }

    //Destructor
    ~FixIt() {
        infx = "";
        pfx = "";
        pvalue1 = 0;
        pvalue2 = 0;
    }

    //Accessors
    string getInfix() {
        return infx;
    }
    string getPostfix() {
        return pfx;
    }
    int getPvalue1() {
        return pvalue1;
    }
    int getPvalue2() {
        return pvalue2;
    }

    //Mutators
    void setInfix(string infx) {
        this->infx = infx;
    }
    void setPostfix(string pfx) {
        this->pfx = pfx;
    }
    void setPvalue1(int pvalue1) {
        this->pvalue1 = pvalue1;
    }
    void setPvalue2(int pvalue2) {
        this->pvalue2 = pvalue2;
    }

    //toString
    string showInfix() {
        return infx;
    }
    string showPostfix() {
        return pfx;
    }

    //Method takes the count from the For loop as a parameter and uses it to return the proper char from the infix string
    char getInfixChar(int i) {
        return infx[i];
    }

    //Method to convert infix to postfix, store in pfx
    void convertToPostfix(stack<char> infix) {
        for (int i = 0; i < getInfix().length(); i++) {//For loop runs the size of the infix expression
            
            if ((getInfixChar(i) >= 'A' && getInfixChar(i) <= 'Z')) {//Check if char is a letter between A-Z
                setPostfix(getPostfix() + getInfixChar(i));
            }

            else if (getInfixChar(i) == '(') {//If char is a '(' push is onto the stack
                infix.push('(');
            }

            //If char is a ')' the while loop will add the top item from the stack to the pfx string and 
            //then pop the top stack until the left parantheses '(' is reached.
            else if (getInfixChar(i) == ')') {
                while (infix.top() != '('){
                    setPostfix(getPostfix() + infix.top());
                    infix.pop();
                }
                //After the '(' is reached the loop will end and discard the '(' from the stack since
                //what was contained inside the paranthese '()' is now in the pfx string 
                infix.pop();
            }

            //If a letter or parantheses was not found then it must be empty (reached the end) or an operator
            else {
                //As long as it's not empty and the order of precedence check returns true the while loop will 
                //add the top of the stack to the pfx string and then pop it from the stack 
                while (!infix.empty() && Precedence(getInfixChar(i), infix.top())){
                    setPostfix(getPostfix() + infix.top());
                    infix.pop();
                }
                //If the stack is empty from while loop, was already empty, or if the infix char is greater precedence the 
                //what's on the top of the stack push that current infix char onto the top of the stack
                infix.push(getInfixChar(i));
            }
        }
        emptyStack(infix);//Add the remaining stack to postfix and empty the stack. 
        endPrompt();//Output final message
    }

    //Method to run through the stack and add anything left in the stack to the postfix string then 
    //remove the char from the stack. Runs until stack is empty
    void emptyStack(stack<char> infix) {
        while (!infix.empty()) {
            setPostfix(getPostfix() + infix.top()); 
            infix.pop();
        }
    }

    //Method takes the current char of the infix expression and the current item on the top of the stack.
    //Each char is assigned a value for precedence and then compared against one another to return a boolean
    bool Precedence(char first, char second){
        //Set/Reset pvalues to 0 before each test, also ensures final test doesn't pass an unsigned integer
        setPvalue1(0);
        setPvalue2(0);
        
        //Paranthesis () 1
        //Add/Sub (+, -) 2
        //Multiply/Divide (*, /) 3
        //Exponent (^) 4

        //Infix operator, assign an int value to pvalue1 for order of precedence
        if (first == '(' || first == ')') {
            setPvalue1(1);
        }
        if (first == '+' || first == '-') {
            setPvalue1(2);
        }
        if (first == '/' || first == '*') {
            setPvalue1(3);
        }
        if (first == '^') {
            setPvalue1(4);
        }

        //Top stack char operator, assign an int value to pvalue2 for order of precedence
        if (second == '(' || second == ')') {
            setPvalue2(1);
        }
        if (second == '+' || second == '-') {
            setPvalue2(2);
        }
        if (second == '/' || second == '*') {
            setPvalue2(3);
        }
        if (second == '^') {
            setPvalue2(4);
        }

        //Compare pvalue1 and pvalue2, return true if value2 (stack) is equal to or greater than pvalue1 (infix char)
        if (getPvalue1() <= getPvalue2()) {
            return true;
        }
        //else return false
        else {
            return false;
        }
    }

    //Method prints Infix and converted Postfix expressions back to user using the to string method for each
    void endPrompt() {
        cout << "Infix expression: " << showInfix() << endl;
        cout << "Postfix expression: " << showPostfix() << endl;
        cout << endl;
    }
};
//
//Main
//
int main() {

    // Declare stack
    stack<char> expression;
    // Declare Object
    FixIt infix;
    
    //Initialize Infix expression 
    infix.setInfix("A+B-C");
    //Send stack to object for use in conversion
    infix.convertToPostfix(expression);
    //Call Destructor to reset the object variables to a blank slate
    infix.~FixIt();
    
    //Test 2
    infix.setInfix("(A+B)*C");
    infix.convertToPostfix(expression);
    infix.~FixIt();
    
    //Test 3
    infix.setInfix("(A+B)*(C-D)");
    infix.convertToPostfix(expression);
    infix.~FixIt();

    //Test 4
    infix.setInfix("A+((B+C)*(E-F)-G)/(H-I)");
    infix.convertToPostfix(expression);
    infix.~FixIt();

    //Test 5
    infix.setInfix("A+B*(C+D)-E/F*G+H");
    infix.convertToPostfix(expression);
    infix.~FixIt();

    //Call Destructor to clear the object variables
    infix.~FixIt();

    return 0;
}
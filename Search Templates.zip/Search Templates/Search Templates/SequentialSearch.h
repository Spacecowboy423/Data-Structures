#pragma once
template <class elemType>
int seqSearch(const elemType list[], int length, const elemType& item) {
	int loc;
	bool found = false;

	loc = 0;

	while (loc < listLength && !found) {
		if (list[loc] == item) {
			found = true;
		}
		else {
			loc++;
		}
	}
	if (found) {
		return loc;
	}
	else {
		return -1;
	}
}//end seqSearch
#include <iostream>
#include "BinarySearch.h"
using namespace std;

int main() {

	int intList[] = { 2, 16, 34, 45, 53, 56, 69, 70, 75, 96 };
	int pos;

	pos = binarySearch(intList, 10, 45);

	if (pos != -1) {
		cout << "Line 10: " << 45 << " from intlist found at position " << pos << endl;
	}
	else {
		cout << "Line 12: " << 45 << " is not in intList " << endl;
	}

	return 0;

}//end Main
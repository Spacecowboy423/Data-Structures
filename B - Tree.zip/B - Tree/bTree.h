#pragma once
#include <iostream>

//*************************************************************
// Author: D.S. Malik
//
// class bTree
// This class specifies the basic operations to implement a
// B-tree.
//*************************************************************

template <class recType, int bTreeOrder>
struct bTreeNode {
	int recCount;
	recType list[bTreeOrder - 1];
	bTreeNode* children[bTreeOrder];
};

template<class elemType, int size>
class listType {
private:
	int maxSize;
	int length;
	elemType listElem[size];
};

template <class recType, int bTreeOrder>
class bTree{
public:
	bool search(const int& searchItem);
		//Function to determine if searchItem is in the B-tree.
		//Postcondition: Returns true if searchItem is found in the
						 //B-tree; otherwise, returns false.

	void insert(const int& insertItem);
		//Function to insert insertItem in the B-tree.
		//Postcondition: If insertItem is not in the the B-tree, it
						 //is inserted in the B-tree.

	void inOrder();
		//Function to do an inorder traversal of the B-tree.

	void preOrder();

	void postOrder();

	bTree();
		//constructor

//Add additional members as needed.
	void searchNode(bTreeNode<recType, bTreeOrder>* current, const int& item, bool& found, int& location);

	void insertBTree(bTreeNode<recType, bTreeOrder>*& root, const recType& insertItem, recType& median, bTreeNode<recType, bTreeOrder>* rightChild, bool& isTaller);

	void insertNode(bTreeNode<recType, bTreeOrder>* current, const recType& insertItem, bTreeNode<recType, bTreeOrder>*& rightChild, int insertPosition);

	void splitNode(bTreeNode<recType, bTreeOrder>* current, const recType& insertItem, bTreeNode<recType, bTreeOrder>* rightChild, int insertPosition, bTreeNode<recType, bTreeOrder>*& rightNode, recType& median);

protected:
	bTreeNode<recType, bTreeOrder> *root;

private:
	void recInorder(bTreeNode<recType, bTreeOrder>* current);

	void recPreorder(bTreeNode<recType, bTreeOrder>* current);

	void recPostorder(bTreeNode<recType, bTreeOrder>* current);
};
#include "bTree.h"

template<>
bTree<int, 5>::bTree() {
	root = nullptr;
}

template<>
void bTree<int, 5>::searchNode(bTreeNode<int, 5>* current, const int& item, bool& found, int& location) {
	
	location = 0;
	
	while (location < current->recCount && item > current->list[location]) {
		location++;
	}

	if (location < current->recCount && item == current->list[location]) {
		found = true;
	}

	else {
		found = false;
	}
}//end searchNode

template<>
bool bTree<int, 5>::search(const int& searchItem) {
	bool found = false;
	int location;
	bTreeNode<int, 5>* current = nullptr;
	current = root;
	
	while (current != nullptr && !found) {
		searchNode(current, searchItem, found, location);
		
		if (!found) {
			current = current->children[location];
		}
	}//end while
	return found;
}//end search

template<>
void bTree<int, 5>::inOrder() {
	recInorder(root);
}//end inOrder

template<>
void bTree<int, 5>::recInorder(bTreeNode<int, 5>* current) {
	if (current != nullptr) {
		recInorder(current->children[0]);

		for (int i = 0; i < current->recCount; i++) {
			std::cout << current->list[i] << " ";
			recInorder(current->children[i + 1]);
		}//end for
	}//end if
}//end recInorder

///////////////////////////////////////////
template<>
void bTree<int, 5>::preOrder() {
	recPreorder(root);
}//end preOrder

template<>
void bTree<int, 5>::recPreorder(bTreeNode<int, 5>* current) {
	if (current != nullptr) {
		for (int i = 0; i < current->recCount; i++) {
			std::cout << current->list[i] << " ";
			recPreorder(current->children[0]);
			recPreorder(current->children[i + 1]);
		}//end for
	}//end if
}//end recPreorder

template<>
void bTree<int, 5>::postOrder() {
	recPostorder(root);
}//end postOrder

template<>
void bTree<int, 5>::recPostorder(bTreeNode<int, 5>* current) {
	if (current != nullptr) {
		recPostorder(current->children[0]);
		
		for (int i = 0; i < current->recCount; i++) {
			recPostorder(current->children[i + 1]);
			std::cout << current->list[i] << " ";
		}//end for
	}//end if
}//end recPostorder

//////////////////////////////////////////////////////////////
template<>
void bTree<int, 5>::insert(const int& insertItem) {
	bool isTaller = false;
	int median;
	bTreeNode<int, 5>* rightChild = nullptr; //* rightChild = nullptr;
	insertBTree(root, insertItem, median, rightChild, isTaller);
	
	if (isTaller) {			//the tree is initially empty or the root was split by the function insertBTree
		bTreeNode<int, 5>* tempRoot;
		tempRoot = new bTreeNode<int, 5>;
		tempRoot->recCount = 1;
		tempRoot->list[0] = median;
		tempRoot->children[0] = root;
		tempRoot->children[1] = rightChild;
		root = tempRoot;
	}

	std::cout << "\nSuccessfully Inserted." << std::endl;
}//end insert

template<>
void bTree<int, 5>::insertBTree(bTreeNode<int, 5>*& root, const int& insertItem, int& median, bTreeNode<int, 5>* rightChild, bool& isTaller) {
	//set found to false
	bool found = false;
	int location;
	bTreeNode<int, 5>* current;
	current = root;

	//check whether current is nullptr or not
	if (current == nullptr) {
		//set median to insertItem
		median = insertItem;
		//set the rightChild to nullptr
		rightChild = nullptr;
		//set isTaller to true
		isTaller = true;
	}//end if
	else {
		//invoke the searchNode method with parameters
		searchNode(current, insertItem, found, location);
		//check if the element is found
		if (found == true) {
			//prompt the user, that element already exists
			std::cout << "Element Already exists." << std::endl;
		}//end if
		else {
			//invoke the insertBTree method with parameters
			insertBTree(current->children[location], insertItem, median, rightChild, isTaller);
			//check isTaller is true or not
			if (isTaller == true) {
				//check whether the current node is full or not
				if (current->recCount < (5 - 1)) {
					//if node is not full, insert the item in correct position
					insertNode(current, insertItem, rightChild, location);
					//set isTaller to false
					isTaller = false;
				}
				else {
					//if the node is fille with items create a reference rightNode
					bTreeNode<int, 5>* rightNode = nullptr;
					bTreeNode<int, 5>* rightNode1 = nullptr;
					rightNode = rightNode1;////////// &(rightNode1)
					//invoke the splitNodemethod with parameters
					std::cout << "\nNow splitting..." << std::endl;
					splitNode(current, insertItem, rightChild, location, rightNode, median);
				}//end else
			}//end if
		}//end else
	}//end else
}//end insertBTree

template<>
void bTree<int, 5>::insertNode(bTreeNode<int, 5>* current, const int& insertItem, bTreeNode<int, 5>*& rightChild, int insertPosition) {
	int index;
	for (index = current->recCount; index > insertPosition; index--) {
		current->list[index] = current->list[index - 1];
		current->children[index + 1] = current->children[index];
	}
	
	current->list[index] = insertItem;
	current->children[index + 1] = rightChild;
	current->recCount++;
}//end insertNode

template<>
void bTree<int, 5>::splitNode(bTreeNode<int, 5>* current, const int& insertItem, bTreeNode<int, 5>* rightChild, int insertPosition, bTreeNode<int, 5>*& rightNode, int& median) {
	rightNode = new bTreeNode<int, 5>;		//allocate memory to for right node
	int mid = (5 - 1) / 2;
	
	if (insertPosition <= mid) {		//new item goes in the first half of the node
		int index = 0;
		int i = mid;

		while (i < 5 - 1) {
			rightNode->list[index] = current->list[i];
			rightNode->children[index + 1] = current->children[i + 1];
			index++;
			i++;
		}//end while

		current->recCount = mid;
		insertNode(current, insertItem, rightChild, insertPosition);
		(current->recCount)--;
		median = current->list[current->recCount];
		rightNode->recCount = index;
		rightNode->children[0] = current->children[current->recCount + 1];
	}//end if
	
	else {		//new item goes in the second half of the node
		int i = mid + 1;
		int index = 0;
		
		while (i < 5 - 1) {
			rightNode->list[index] = current->list[i];
			rightNode->children[index + 1] = current->children[i + 1];
			index++;
			i++;
		}//end while
		current->recCount = mid;
		rightNode->recCount = index;
		median = current->list[mid];
		insertNode(rightNode, insertItem, rightChild, insertPosition - mid - 1);
		rightNode->children[0] = current->children[current->recCount + 1];
	}//end else
}//splitNode
#include "bTree.h"

int main() {
	
	bTree<int, 5> ob;
	ob.insert(10);
	ob.insert(20);
	ob.insert(30);
	ob.insert(40);
	ob.insert(50);
	ob.insert(25);

	std::cout << "Printing in-order Traversal:" << std::endl;
	ob.inOrder();
	std::cout << std::endl;
	
	std::cout << "Printing pre-order Traversal:" << std::endl;
	ob.preOrder();
	std::cout << std::endl;
	
	std::cout << "Printing post-order Traversal:" << std::endl;
	ob.postOrder();
	std::cout << std::endl;

	return 0;
}
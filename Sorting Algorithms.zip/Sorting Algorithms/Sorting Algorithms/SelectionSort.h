#pragma once
//Selection sort best case is O(n)
//Selection sort worst case is O(n^2)
//Selection sort is best used for small list, as it grows n^2 grows rapidly (exponentially)


template <class elemType>
int minLocation(elemType list[], int first, int last) {
	int minIndex;

	minIndex = first;

	for (int loc = first + 1; loc <= last; loc++) {
		if (list[loc] < list[minIndex]) {
			minIndex = loc;
		}
	}
	return minIndex;
}//end minLocation


template <class elemType>
void swap(elemType list[], int first, int second) {
	elemType temp;

	temp = list[first];
	list[first] = list[second];
	list[second] = temp;
}//end swap

template <class elemType>
void selectionSort(elemType list[], int length) {
	int minIndex;

	for (int loc = 0; loc < length; loc++) {
		minIndex = minLocation(list, loc, length - 1);
		swap(list, loc, minIndex);
	}
}//end selectionSort
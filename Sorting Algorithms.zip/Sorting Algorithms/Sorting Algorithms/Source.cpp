//Best case bubble sort is O(n)
//Worst case bubble sort is O(n^2)

#include <iostream>
#include "BubbleSort.h"
#include "SelectionSort.h"
using namespace std;

template <class elemType>	//defined at bottom
void print(elemType list[], int length);

int main() {
	
	int intList[] = {2, 56, 34, 25, 73, 46, 89, 10, 5, 16};
	//Length of list is 10
	
	//Bubble Sort
	cout << "Before sorting, intList: ";
	print(intList, 10);
	bubbleSort(intList, 10);
	cout << "Bubble sort, intList: ";
	print(intList, 10);
	cout << endl;

	//Selection Sort
	for (int i = 0; i < 10; i++) {		//use same array to create a new list for selection sort
		switch (i) {
		case 0:
			intList[i] = 20;
			break;

		case 1:
			intList[i] = 19;
			break;

		case 2:
			intList[i] = 45;
			break;
		
		case 3:
			intList[i] = 65;
			break;
		
		case 4:
			intList[i] = 32;
			break;
		
		case 5:
			intList[i] = 99;
			break;
		
		case 6:
			intList[i] = 87;
			break;
		
		case 7:
			intList[i] = 54;
			break;
		
		case 8:
			intList[i] = 73;
			break;
		
		case 9:
			intList[i] = 1;
			break;
		}//end switch case
	}//end for loop

	cout << "Before sorting new list, intList: ";
	print(intList, 10);
	selectionSort(intList, 10); //defined in header
	cout << "Selection sort of new list, intList: ";
	print(intList, 10);
	cout << endl;

	return 0;
}//end main

template<class elemType>
void print(elemType list[], int length) {
	for (int i = 0; i < length; i++) {
		cout << list[i] << " ";
	}
	cout << endl;
}//end print
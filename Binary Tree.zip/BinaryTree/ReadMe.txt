Program Name: Binary Trees!
Author: Michael Krause
Last Update: 04-07-2022 
Purpose: This program allows the user to enter int values into 1 and/or 2 binary trees. Once finished the program will print the tree using all
3 traversal methods to do so. Will delete a node and then reprint the tree. Will make a copy of the tree and delete both trees. Output will
be given after each test of the tree. Once a tree is created the number of nodes, leaves, single parents, and tree height will be found and printed. 
The goal is to show off the abilities of the binary tree and use proper input validation and exception handling to do so.

2) Programming Exercise #4 (pg. 1414)
Write a function, singleParent, that returns the number of nodes in a binary tree that have only one child.  
Add this function the class binaryTreeType and create a program to test this function.  (NOTE: First create a binary search tree.)


My Solution:
I prompt the user to begin entering elements into the binary tree using a string variable. I did this to use the same variable for user input to also
input elements into the tree of int type. The first check after input is whether the user enters the letter 'n' to end the user entry or send the 
variable to the isDigit() function to run through the string one char at a time and check that the value is between the "0" and "9" asci values. If 
the function returns true then the main converts it to an int and inserts it into the tree. After this I used as many of the build in functions from 
the class within the program and to print output back to the user. After the user is done entering values for the first tree they are given the 
option to enter values into another tree. Depending on whether or not information is entered into the second tree will determine if another set of 
functions are called and executed. But then I just ended the program calling the destructor of the derived class which calls the destructor from 
the parent class.

NodeCount():
I actually mimicked this directly from the inorder traversal. Any of the traversal methods traverse the entire tree. So instead of printing the node
I just had to have a counter going. By returning 1 on each recursive method I didn't need to create a variable to track the count. Kind of like it
was doing it automatically and then the base case would return 0 if the current node null.

leavesCount():
I was actually able to use what I did in node count to make leavesCount. I was able to use the same method of traversing the tree but I didn't need
to track the count of the tree I only wanted the nodes with no parents. So by checking the left and right link of each node for a double null link
I would find my node and return 1 for finding a leaf node.

singleParentCount():
This function is a public function that is only used to call the private function singleParent()

singleParent():
I modeled this after the previous two methods of tree traversal and identifying a leaf to build a check for a single parent node. Since a single
parent node has only one left or right link I use the two if statements to check if it's a right parent (left is null and right is not) or a left
parent (right null and left is not). If it does not meet the constraints of a single parent I simply traverse the tree with the else statement.
If a right parent is found I return one to keep track of the count and then continue down the right side of the tree since the left is null. 
If a left parent is found I return one to keep track of the count and then continue down the left side of the tree since the right is null.
Base case always checks if the node is null and returns 0 if so.
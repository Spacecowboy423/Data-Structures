/*
Program Name: Binary Trees!
Author: Michael Krause
Last Update: 04-07-2022 
Purpose: This program allows the user to enter int values into 1 and/or 2 binary trees. Once finished the program will print the tree using all
3 traversal methods to do so. Will delete a node and then reprint the tree. Will make a copy of the tree and delete both trees. Output will
be given after each test of the tree. Once a tree is created the number of nodes, leaves, single parents, and tree height will be found and printed. 
The goal is to show off the abilities of the binary tree and use proper input validation and exception handling to do so.
*/

//This is the program code from the book. 
//The StackADT and StackType header files don't work with the program. 
//I'm still working on that but I was able to get the rest working just fine
//#include "bSearchTreeType.h"
//#include <iostream>
//using namespace std;
//
//void print(int& x);
//void update(int& x);
//
//int main() { 
//
//	bSearchTreeType<int> treeRoot;
//	int num; 
//
//	cout << "Line 10: Enter numbers ending with -999" << endl;
//	cin >> num;
//
//	while (num != -999){ 
//		treeRoot.insert(num);
//		cin >> num;
//	} 
//	
//	cout << endl << "Line 17: Tree nodes in inorder: "; 
//
//	treeRoot.inorderTraversal(print);
//	cout << endl << "Line 19: Tree Height: " << treeRoot.treeHeight() << endl << endl; 
//	cout << "Line 20: ******* Update Nodes *******" << endl; 
//	
//	treeRoot.inorderTraversal(update); 
//	cout << "Line 22: Tree nodes in inorder after " << "the update: " << endl << " ";
//	
//	treeRoot.inorderTraversal(print); 
//	cout << endl << "Line 24: Tree Height: " << treeRoot.treeHeight() << endl; 
//	
//	return 0; 
//}
//void print(int& x){ 
//	cout << x << " ";
//} 
//void update(int& x){
//	x = 2 * x; 
//}

#include "binaryTreeType.h"
#include "bSearchTreeType.h"
#include <iostream>
#include <string>
using namespace std;

bool isDigit(string userInput) {
	//Check input is an int
	for (int i = 0; i < userInput.length(); i++) {
		if (userInput[i] < '0' || userInput[i] > '9') {
			return false;
		}
	}
	return true;
}

int main() {
	bSearchTreeType<int> binaryTree;			//Declare object of type int
	bSearchTreeType<int> binaryTree2;			//Declare second object of type int
	int element;								//Declare program variable for element insert
	string userInput;							//Declare program variable for user input
	bool boolean = true;						//Declare and initialize boolean for main program loop

	//Prompt the user with the proper input needed
	cout << "Enter as may elements as you would like. Once finished enter 'n' to end loop." << endl;

	while (boolean) {
		try {
			//Prompt the user to enter an input
			cout << "Enter an element for input: ";
			cin >> userInput;

			//Check input for loop end condition
			if (userInput == "n") {
				boolean = false;
				continue;
			}

			if (isDigit(userInput)) {
				element = stoi(userInput);	//Convert the input values from string to int (supported on c++11 and newer)
				binaryTree.insert(element);	//insert the element into the binary tree
			}
			else {
				throw string("Invalid Entry: Only input integer values.");	//if digit check returns false error string is thrown into the input stream
			}
		}

		catch (string err) {		//error thrown in input stream is caught
			cout << endl;			//for spacing purposes on output
			cout << err << endl;	//print error message to console
			cin.clear();			//clear the stream after the message has been printed
			cin.ignore(1, '\n');	//ignore anything left behind after clear
			cout << endl;			//for spacing purposes on output
		}
	}

	//Prompt the user with the proper input needed
	cout << endl;
	cout << "Enter as may elements as you would like for the second tree. Once finished enter 'n' to end loop." << endl;
	boolean = true;

	while (boolean) {
		try {
			//Prompt the user to enter an input
			cout << "Enter an element for input: ";
			cin >> userInput;

			//Check input for loop end condition
			if (userInput == "n") {
				boolean = false;
				continue;
			}

			if (isDigit(userInput)) {
				element = stoi(userInput);		//Convert the input values from string to int (supported on c++11 and newer)
				binaryTree2.insert(element);	//insert the element into the binary tree
			}
			else {
				throw string("Invalid Entry: Only input integer values.");	//if digit check returns false error string is thrown into the input stream
			}
		}

		catch (string err) {		//error thrown in input stream is caught
			cout << endl;			//for spacing purposes on output
			cout << err << endl;	//print error message to console
			cin.clear();			//clear the stream after the message has been printed
			cin.ignore(1, '\n');	//ignore anything left behind after clear
			cout << endl;			//for spacing purposes on output
		}
	}

	if (!binaryTree.isEmpty()) {
		//Display elements order
		cout << endl;
		cout << "The tree elements in inorder from binary Tree 1: ";
		binaryTree.inorderTraversal();											//Print the inorder traversal of the tree
		cout << endl;
		cout << "The tree height: " << binaryTree.treeHeight() << endl;			//Print the height of the tree - longest path from root to some leaf
		cout << "The tree Leaves: " << binaryTree.treeLeavesCount() << endl;	//Print the number of leaf nodes in the tree - no children nodes
		cout << "The tree Nodes: " << binaryTree.treeNodeCount() << endl;		//Print the number of nodes in the tree
		cout << "The number of Single Parent Nodes is: " << binaryTree.singleParentCount() << endl;		//Print the single parent count of the tree to the user - number of parent nodes with only one child node

		//Display output
		//cout << "\nThe Post Order Traversal: ";
		//binaryTree.postorderTraversal();	//Print the postorder traversal of the tree
		//cout << "\nThe Pre Order Traversal: ";
		//binaryTree.preorderTraversal();		//Print the preorder traversal of the tree
		//cout << endl;
		//cout << endl;

		//Display output
		cout << "Delete Node 3 from tree 1, if no node nothing will happen." << endl;
		binaryTree.deleteNode(3);		//If the number three exists in tree, remove it
		cout << "In Order after deletion: ";	
		binaryTree.inorderTraversal();	//Print the inorder traversal of the tree after deletion
		cout << endl;
		//cout << "Post Order after deletion: ";
		//binaryTree.postorderTraversal();	//Print the postorder traversal of the tree after deletion
		//cout << endl;
		//cout << "Pre Order after deletion: ";
		//binaryTree.preorderTraversal();		//Print the preorder traversal of the tree after deletion
		//cout << endl;
		cout << endl;

		if (!binaryTree2.isEmpty()) {
			//Display elements order
			cout << endl;
			cout << "The tree elements in inorder from binary Tree 2: ";
			binaryTree2.inorderTraversal();		//Print the inorder traversal of the tree
			cout << endl;
			cout << "The tree height: " << binaryTree2.treeHeight() << endl;		//Print the height of the tree - longest path from root to some leaf
 			cout << "The tree Leaves: " << binaryTree2.treeLeavesCount() << endl;	//Print the number of leaf nodes in the tree - no children nodes
			cout << "The tree Nodes: " << binaryTree2.treeNodeCount() << endl;		//Print the number of nodes in the tree
			cout << "The number of Single Parent Nodes is: " << binaryTree2.singleParentCount() << endl;	//Print the single parent count of the tree to the user - number of parent nodes with only one child node

			//Display output
			//cout << "\nThe Post Order Traversal: ";
			//binaryTree2.postorderTraversal();	//Print the postorder traversal of the tree
			//cout << "\nThe Pre Order Traversal: ";
			//binaryTree2.preorderTraversal();	//Print the preorder traversal of the tree
			//cout << endl;
			cout << endl;
			cout << "Delete Node 8 from tree 2, if no node nothing will happen." << endl;
			binaryTree2.deleteNode(8);			//If the key 8 is contained in the tree, remove it
			cout << "In Order after deletion: ";
			binaryTree2.inorderTraversal();		//Print the inorder traversal of tree after deletion
			cout << endl;
			//cout << "Post Order after deletion: ";
			//binaryTree2.postorderTraversal();	//Print the postorder traversal of tree after deletion
			//cout << endl;
			//cout << "Pre Order after deletion: ";
			//binaryTree2.preorderTraversal();	//Print the preorder traversal of tree after deletion
			//cout << endl;
			cout << endl;

			//Use overloaded assignement operator to set tree 1 to tree 2
			binaryTree = binaryTree2;
			cout << "Tree 1 is now a hard copy of Tree 2: ";
			binaryTree.inorderTraversal();		//Print the inorder traversal of tree
			cout << endl;

			//Display output
			cout << "Tree 1 will be destroyed.";
			binaryTree.~bSearchTreeType();		//Destructor from the parent class gets called since one does not exist in derived class
			cout << endl;
			cout << "Tree 1 has been destroyed, nothing should print from the next line of code: ";
			binaryTree.inorderTraversal();		//Print the inorder traversal of tree
			cout << endl;
			cout << endl;
			cout << "Tree 2 still exist though: ";
			binaryTree2.inorderTraversal();		//Print the inorder traversal of treee
			cout << endl;
			binaryTree2.~bSearchTreeType();		//Destructor from the parent class gets called since one does not exist in derived class
			cout << "Tree 2 has now been deleted." << endl;
		}//end inner if
		else {
			cout << "Tree 2 is empty." << endl;
		}//end else
	}//end outer if
	else {
		cout << endl;
		cout << "Tree 1 must be filled, Tree 2 is optional." << endl;
	}
	return 0;
}//end main

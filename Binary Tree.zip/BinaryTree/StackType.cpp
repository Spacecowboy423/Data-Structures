#include "StackType.h"
#include <cassert>
#include <iostream>
using namespace std;

//*************************************************************
// Author: D.S. Malik
//
// This class specifies the basic operation on a stack as an
// array.
//*************************************************************

template <>
const stackType<int>& stackType<int>::operator=(const stackType<int>& otherStack) {
	if (this != &otherStack) //avoid self-copy
		copyStack(otherStack);
	return *this;
}
	//Overload the assignment operator.
template <>
void stackType<int>::initializeStack() {
	stackTop = 0;
}
	//Function to initialize the stack to an empty state.
	//Postcondition: stackTop = 0;

template <>
bool stackType<int>::isEmptyStack() const {
	return(stackTop == 0);
}
	//Function to determine whether the stack is empty.
	//Postcondition: Returns true if the stack is empty,
	// otherwise returns false.

template <>
bool stackType<int>::isFullStack() const {
	return(stackTop == maxStackSize);
}
	//Function to determine whether the stack is full.
	//Postcondition: Returns true if the stack is full,
	// otherwise returns false.

template <>
void stackType<int>::push(const int& newItem) {
	if (!isFullStack())
	{
		list[stackTop] = newItem; //add newItem at the top
		stackTop++; //increment stackTop
	}
	else
		cout << "Cannot add to a full stack." << endl;
}
	//Function to add newItem to the stack.
	//Precondition: The stack exists and is not full.
	//Postcondition: The stack is changed and newItem is
	// added to the top of the stack.

template <>
int stackType<int>::top() const {
	assert(stackTop != 0); //if stack is empty, terminate the program
	return list[stackTop - 1]; //return the element of the stack
	//indicated by stackTop - 1
}
	//Function to return the top element of the stack.
	//Precondition: The stack exists and is not empty.
	//Postcondition: If the stack is empty, the program
	// terminates; otherwise, the top element of the stack
	// is returned.

template <>
void stackType<int>::pop() {
	if (!isEmptyStack())
		stackTop--; //decrement stackTop
	else
		cout << "Cannot remove from an empty stack." << endl;
}
	//Function to remove the top element of the stack.
	//Precondition: The stack exists and is not empty.
	//Postcondition: The stack is changed and the top element is
	// removed from the stack.

template <>
stackType<int>::stackType(int stackSize) {
	if (stackSize <= 0)
	{
		cout << "Size of the array to hold the stack must "
			<< "be positive." << endl;
		cout << "Creating an array of size 100." << endl;
		maxStackSize = 100;
	}
	else
		maxStackSize = stackSize; //set the stack size to
		//the value specified by
		//the parameter stackSize
	stackTop = 0; //set stackTop to 0
	list = new int[maxStackSize]; //create the array to
	//hold the stack elements
}
	//Constructor
	//Create an array of the size stackSize to hold
	//the stack elements. The default stack size is 100.
	//Postcondition: The variable list contains the base address
	// of the array, stackTop = 0, and maxStackSize = stackSize

template <>
stackType<int>::stackType(const stackType<int>& otherStack) {
	list = NULL;
	copyStack(otherStack);
}
	//Copy constructor

template <>
stackType<int>::~stackType() {
	delete[] list; //deallocate the memory occupied
	//by the array
}
	//Destructor
	//Remove all the elements from the stack.
	//Postcondition: The array (list) holding the stack
	// elements is deleted.

template <>
void stackType<int>::copyStack(const stackType<int>& otherStack) {
	delete[] list;
	maxStackSize = otherStack.maxStackSize;
	stackTop = otherStack.stackTop;
	maxStackSize = 100;
	
	list = new int[maxStackSize];

	//copy otherStack into this stack
	for (int j = 0; j < stackTop; j++)
		list[j] = otherStack.list[j];
}
	//Function to make a copy of otherStack.
	//Postcondition: A copy of otherStack is created and assigned
	// to this stack.
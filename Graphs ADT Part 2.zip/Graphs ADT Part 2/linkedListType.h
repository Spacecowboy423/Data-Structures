// Taken from the C++ programming: Program Design Including Data Structures.

#pragma once
#include <iostream>
#include <cassert>
#pragma once
#include "linkedListIterator.h"

template<class Type>
class linkedListType {
public:
	// Overload the assignment operator.
	const linkedListType<Type>& operator=(const linkedListType<Type>& otherList);

	// Initializes the list to an empty state.
	// Postcondition: first = nullptr, last = nullptr, count = 0;
	void initializeList();

	// Function to determine whether the list is empty.
	// Postcondition: Returns true if the list is empty, otherwise it returns false.
	bool isEmptyList() const;

	// Function to output the data contained in each node.
	// Postcondition: none
	void print() const;

	// Function to return the number of nodes in the list.
	// Postcondition: The value of count is returned.
	int length() const;

	// Function to delte all the nodes from the list.
	// Postcondition: first = nullptr, last = nullptr, count = 0;
	void destroyList();

	// Function to return the first element of the list.
	// Precondition: The list must exist and must not be empty.
	// Postcondition: If the list is empty, the program terminates; otherwise, the first element of the list is returned.
	Type front() const;

	// Function to return the last element of the list.
	// Precondition: The list must exist and must not be empty.
	// Postcondition: If the list is empty, the program terminates; otherwise, the last element of the list is returned.
	Type back() const;

	// Function to determine whether searchItem is in the list.
	// Postcondition: Returns true if searchItem is in the list, otherwise the value is false is returned.
	virtual bool search(const Type& searchItem) const = 0;
	
	// Function to insert newItem at the end of the list.
	// Postcondition: First points to the new list, newItem is inserted at the
	// end of the list, last points to the last node in the list, and count is incremented by 1.
	virtual void insertFirst(const Type& newItem) = 0;

	// Function to delete deleteItem from the list.
	// Postcondition: If found, the node containing deleteItem is deleted from the list.
	// first points to the first node, last points to the last node of the updated list, and count is decremented by 1.
	virtual void deleteNode(const Type& deleteItem) = 0;

	// Function to return an iterator at the beginning of the linked list.
	// Postcondition: Returns an iterator such that current is set to nullptr.
	linkedListIterator<Type> begin();

	// Function to return an iterator one element past the last element of the linked list.
	// Postcondition: Returns an iterator such that current is set to nullptr.
	linkedListIterator<Type> end();

	// Default constructor.
	// Initializes the list to an empty state.
	// Postcondition: first = nullptr, last = nullptr, count = 0;
	linkedListType();

	// Copy constructor
	linkedListType(const linkedListType<Type>& otherList);

	// Destructor
	// Deletes all the nodes from the list.
	// Postcondition: The list object is destroyed.
	~linkedListType();

protected:
	int count; // Variable to store the number of elements in the list.

	nodeType<Type>* first; // Points to the first node of the linked list.
	nodeType<Type>* last; // Points to the last node of the linked list.

private:
	// Function to make a copy of otherList.
	// Postcondition: A copy of otherList is created and assigned to this list.
	void copyList(const linkedListType<Type>& otherList);
};


// Initializes the list to an empty state.
// Postcondition: first = nullptr, last = nullptr, count = 0;
template<class Type>
void linkedListType<Type>::initializeList() {
	destroyList(); // If the list has any nodes, delete them.
}

// Function to determine whether the list is empty.
// Postcondition: Returns true if the list is empty, otherwise it returns false.
template<class Type>
bool linkedListType<Type>::isEmptyList() const {
	return(first == nullptr);
}

// Function to output the data contained in each node.
// Postcondition: none
template<class Type>
void linkedListType<Type>::print() const {
	nodeType<Type>* current; // pointer to traverse the list.

	current = first; // Set current do that it points to the first node.

	while (current != nullptr) { // While more data to print
		std::cout << current->info << " ";
		current = current->link;
	}
} // End print.

// Function to return the number of nodes in the list.
// Postcondition: The value of count is returned.
template<class Type>
int linkedListType<Type>::length() const {
	return count;
}

// Function to delte all the nodes from the list.
// Postcondition: first = nullptr, last = nullptr, count = 0;
template<class Type>
void linkedListType<Type>::destroyList() {
	nodeType<Type>* temp; // Pointer to deallocate memory occupied by the node.
	
	// While there are nodes in the list
	while (first != nullptr) {
		
		temp = first; // Set temp to current node.

		first = first->link; // Advance first to the next node.
		delete temp; // Deallocate the memory occupied by temp.

	} // End of while.

	last = nullptr; // Initializes last to nullptr; first has already been set to nullptr by the while loop.
	count = 0;
}

// Function to return the first element of the list.
// Precondition: The list must exist and must not be empty.
// Postcondition: If the list is empty, the program terminates; otherwise, the first element of the list is returned.
template<class Type>
Type linkedListType<Type>::front() const {
	
	assert(first != nullptr);
	
	return first->info; // Return the info of the first node.
}

// Function to return the last element of the list.
// Precondition: The list must exist and must not be empty.
// Postcondition: If the list is empty, the program terminates; otherwise, the last element of the list is returned.
template<class Type>
Type linkedListType<Type>::back() const {
	assert(last != nullptr);

	return last->info;
}


// Function to return an iterator at the beginning of the linked list.
// Postcondition: Returns an iterator such that current is set to nullptr.
template<class Type>
linkedListIterator<Type> linkedListType<Type>::begin() {
	linkedListIterator<Type> temp(first);

	return temp;
}

// Function to return an iterator one element past the last element of the linked list.
// Postcondition: Returns an iterator such that current is set to nullptr.
template<class Type>
linkedListIterator<Type> linkedListType<Type>::end() {

	linkedListIterator<Type> temp(last);		//changed last->link to last and it appears to work

	return temp;

}
template<class Type>
void linkedListType<Type>::copyList(const linkedListType<Type>& otherList) {
	nodeType<Type>* newNode; // Pointer to create a node.
	nodeType<Type>* current; // Pointer to traverse the list.

	if (first != nullptr) // if the list is nonempty, make it empty.
		destroyList();

	if (otherList.first == nullptr) { // otherList is empty.
		first = nullptr;
		last = nullptr;
		count = 0;
	}
	else {
		current = otherList.first; // current points to the list to be copied.

		count = otherList.count;

		// Copy the first node.
		first = new nodeType<Type>; // Create the node.

		first->info = current->info; // Copy the info.
		first->link = nullptr; // set the link field of the node to nullptr.

		last = first; // Make last point to the first node.

		current = current->link; // Make current point to the next node.

		// Copy the remaining list.
		while (current != nullptr) {
			newNode = new nodeType<Type>; // Create new node.
			newNode->info = current->info; // Copy the info.

			last->link = newNode; // Attach newNode after last.
			last = newNode; // Make last point to the actual last node.

			current = current->link; // Make current point to the next node.
		} // End of while.
	} // End of else.
} // End of copyList.

// Default constructor.
// Initializes the list to an empty state.
// Postcondition: first = nullptr, last = nullptr, count = 0;
template<class Type>
linkedListType<Type>::linkedListType() {
	first = nullptr;
	last = nullptr;
	count = 0;
}

// Copy constructor
template<class Type>
linkedListType<Type>::linkedListType(const linkedListType<Type>& otherList) {
	
	first = nullptr;
	copyList(otherList); // Uses copyList member function to copy the list passed to the copy constructor.
}

// Destructor
// Deletes all the nodes from the list.
// Postcondition: The list object is destroyed.
template<class Type>
linkedListType<Type>::~linkedListType() {
	destroyList(); // Destroys list by deallocating memory to all the nodes.
}

// Overload the assignment operator.
template<class Type>
const linkedListType<Type>& linkedListType<Type>::operator=(const linkedListType<Type>&otherList) {

	if (this != &otherList) { // Avoids self-copy of the list. 
		copyList(otherList);
	}

	return *this;
}
Program Name: Traversing Digital Graph
Author: Michael Krause
Last Update: 4/22/2022
Purpose: Using a linked lists to create a graph and adjaceny list to store and print information. Information can be printed as the
adjaceny, breadth first, or depth first traversal.

Problem Statement:
Programming Exercise 1: Write a program that outputs the nodes of a graph in a depth-first traversal.
Programming Exercise 2: Write a program that outputs the nodes of a graph in a breadth-first traversal.

My Execution:
The main problem with the program is that it only allows the graph to made of values between the smallest index and largest
index and no numbers can be repeated within the graph. I did not catch that so I had to make a lot of changes. The numbers.txt
is used to create the graph and the num.txt is used to fill an array with all the vertices (vint[]). Then I repurposed the 
array to track whether a vertex has been visited (vistited[]) to run parellel with the vint[]. This ensures that if there are
dublicate values in the graph they don't get repeated or printed twice. 

This took quite a bit of time to figure out so my program is fairly simple. I have the program open the file at execution and 
iterate through the file counting the number of vertices. Once done the file is closed and the count is used to declare the
graph with the correct size of vertices. Within each function for depth first traversal and breadth first traversal I reopen
the file to fill the vint[] array with the vertices and fill the visitied[] array with false to show it hasn't been visited.
This could have been shorted if I used a class variable or a global array but for the sake of a functing program and proof 
of concept it works perfectly doing this. At each check to print a vertex is a for loop that runs through the parallel arrays
until it finds the current value we are looking for, checks it against the value in the vint[] array and then checks the 
corresponding visited[] array to know if it has been visited and printed already.

The reason I needed to make this change is because of an issue where the program would be coming in with an index value 
greater than the size of the visited[] array it would error or cause the program to access a random memory location. So 
if the indices of the visited array is only 0-4 but I have a value linked to one vertex of anything greater than 4 the 
program would error. It would come into the conditional to check if a node has been visited by using a value greater 
than the size of the array and either error or access a random memory location.
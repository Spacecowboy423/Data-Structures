#pragma once
#include <iostream>
#include <cassert>

template <class Type>
struct nodeType {
	Type info;
	nodeType<Type>* link;
};

template<class Type>
class linkedListIterator {
public:
	// Default Constructor.
	// Postcondition: current = nullptr;
	linkedListIterator();

	linkedListIterator(nodeType<Type> *ptr);

	void getCurrent();

	// Function to overload the dereferencing operator *.
	// Postcondition: Returns the info contained in the node.
	Type operator*();

	linkedListIterator<Type> operator++();

	// Overload the equality operator.
	// Postcondition: Returns true if this iterator is equal to the iterator 
	// specified by right, otherwise it returns false.
	bool operator==(const linkedListIterator<Type>& right) const;

	bool operator!=(const linkedListIterator<Type>& right) const;

private:
	nodeType<Type>* current;
};

template<class Type>
void linkedListIterator<Type>::getCurrent() {
	std::cout << current << "\n";
	return;
}

template<class Type>
linkedListIterator<Type>::linkedListIterator() {
	//std::cout << "linkedListIterator()" << std::endl;
	current = nullptr;
}

template<class Type>
linkedListIterator<Type>::linkedListIterator(nodeType <Type>* ptr) {
	//std::cout << "linkedListIterator(nodeType <Type>* ptr)" << std::endl;
	current = ptr;
}

// Function to overload the dereferencing operator *.
// Postcondition: Returns the info contained in the node.
template<class Type>
Type linkedListIterator<Type>::operator*() {
	assert(current != nullptr);
	return current->info;

}


template<class Type>
linkedListIterator<Type> linkedListIterator<Type>::operator++() {
	//std::cout << "operator++()" << std::endl;
	current = current->link;
	return *this;
}

// Overload the equality operator.
// Postcondition: Returns true if this iterator is equal to the iterator 
// specified by right, otherwise it returns false.
template<class Type>
bool linkedListIterator<Type>::operator==(const linkedListIterator<Type>& right) const {
	//std::cout << "operator==(const linkedListIterator<Type>& right) const" << std::endl;
	return(current == right.current);
}

template<class Type>
bool linkedListIterator<Type>::operator!=(const linkedListIterator<Type>& right) const {
	//std::cout << "operator!=(const linkedLIstIterator<Type>& right) const" << std::endl;
	return(current != right.current);
}
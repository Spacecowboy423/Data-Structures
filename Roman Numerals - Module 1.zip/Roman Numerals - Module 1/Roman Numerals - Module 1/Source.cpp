/*
Project Name: Roman to Decimal and back again
Author: Michael Krause
Last Update: 1/24/2022
Purpose: To give the user the option to put in a Roman Numeral and have it converted to a Decimal Number
or to enter a Decimal Number and have it converted into a Roman Numeral. Once the user is done converting
the user is given the option to end the program or go round again.
*/

#include <iostream>
#include <string>
using namespace std;

class romanType{
private:
	//Fields
	string RomanNumeral;
	int DecimalNumber;

public:
	//Default Constructor
	romanType() {
		this->RomanNumeral = "";
		this->DecimalNumber = 0;
	}

	//Parameterized Constructor
	romanType(string RomanNumeral) {
		this->RomanNumeral = RomanNumeral;
		this->DecimalNumber = 0;
	}

	//Destructor
	~romanType() {

	}

	//Accessors
	int getDecimalNumber() {
		return this->DecimalNumber;
	}
	string getRomanNumeral() {
		return this->RomanNumeral;
	}

	//Mutators
	void setRomanNumeral(string RomanNumeral) {
		this->RomanNumeral = RomanNumeral;
	}
	void setDecimalNumber(int DecimalNumber) {
		this->DecimalNumber = DecimalNumber;
	}

	//Methods
	void RomanToDecimal() {
		//Temp will be used to contain each converted Roman Numeral Value
		int Temp = 0;

		//Stores the RomanNumeral entered from user to a string variable UserInput
		string UserString = RomanNumeral;

		//Loop to go through Roman Numberals to find Decimal Value
		for (int i = 0; i < UserString.length(); i++) {
			//Loop runs through each character in the string to find its value
			int Decimal1;
			char Numeral1 = UserString[i];
			if (Numeral1 == 'I') {
				Decimal1 = 1;
			}
			if (Numeral1 == 'V') {
				Decimal1 = 5;
			}
			if (Numeral1 == 'X') {
				Decimal1 = 10;
			}
			if (Numeral1 == 'L') {
				Decimal1 = 50;
			}
			if (Numeral1 == 'C') {
				Decimal1 = 100;
			}
			if (Numeral1 == 'D') {
				Decimal1 = 500;
			}
			if (Numeral1 == 'M') {
				Decimal1 = 1000;
			}
			//Checks the next value in the string to find its value
			if (i + 1 < UserString.length()) {
				int Decimal2;
				char Numeral2 = UserString[i + 1];
				if (Numeral2 == 'I') {
					Decimal2 = 1;
				}
				if (Numeral2 == 'V') {
					Decimal2 = 5;
				}
				if (Numeral2 == 'X') {
					Decimal2 = 10;
				}
				if (Numeral2 == 'L') {
					Decimal2 = 50;
				}
				if (Numeral2 == 'C') {
					Decimal2 = 100;
				}
				if (Numeral2 == 'D') {
					Decimal2 = 500;
				}
				if (Numeral2 == 'M') {
					Decimal2 = 1000;
				}
				//Compares both values to find which rule of Roman Numerals to apply (addition or subtraction)
				if (Decimal1 >= Decimal2) {
					Temp += Decimal1;
				}
				//Handle the subtraction
				else {
					Temp += (Decimal2 - Decimal1);
					i++;
				}
			}
			//To handle the last value in UserString[]
			else {
				Temp += Decimal1;
				i++;
			}
		}
		//Update the object variable with the conversion from Roman Numeral
		this->DecimalNumber = Temp;
	}
	void DecimalToRoman() {
		//TempString will be used to form the RomanNumeral and TempDec is a copy of the decimal entered by user
		string TempString = "";
		int TempDec = DecimalNumber;

		/*
		The while loop will continue until the value of TempDec reaches zero.
		There are special rules surrounding the values 4 (IV), 9 (IX), 40-49 (XL), 90-99 (XC), 400-499(CD), 900-999 (CM) to prevent 
		4 symbols of a kind from being repeated sequentially. Technicaly Roman Numerals stop at 3999 but my program will accept 
		any number. If you go to high, prepare for a lot of 'M' numerals. I could have prevented this with a limit of 3999 in 
		my loop and validation but it still works just find without it and it was more fun to leave it out, in my opinion.
		*/
		while (TempDec > 0) {
			if (TempDec >= 1000) {
				TempDec -= 1000;
				TempString += 'M';
				continue;
			}
			if (TempDec >= 900 && TempDec <= 999) {
				TempDec -= 900;
				TempString += 'C';
				TempString += 'M';
				continue;
			}
			if (TempDec >= 500) {
				TempDec -= 500;
				TempString += 'D';
				continue;
			}
			if (TempDec >= 400 && TempDec <= 499) {
				TempDec -= 400;
				TempString += 'C';
				TempString += 'D';
				continue;
			}
			if (TempDec >= 100) {
				TempDec -= 100;
				TempString += 'C';
				continue;
			}
			if (TempDec >= 90 && TempDec < 99) {
				TempDec -= 90;
				TempString += 'X';
				TempString += 'C';
				continue;
			}
			if (TempDec >= 50) {
				TempDec -= 50;
				TempString += 'L';
				continue;
			}
			if (TempDec >= 40 && TempDec <= 49) {
				TempDec -= 40;
				TempString += 'X';
				TempString += 'L';
				continue;
			}
			if (TempDec >= 10) {
				TempDec -= 10;
				TempString += 'X';
				continue;
			}
			if (TempDec == 9) {
				TempDec -= 9;
				TempString += 'I';
				TempString += 'X';
				continue;
			}
			if (TempDec >= 5) {
				TempDec -= 5;
				TempString += 'V';
				continue;
			}
			if (TempDec == 4) {
				TempDec -= 4;
				TempString += 'I';
				TempString += 'V';
				continue;
			}
			if (TempDec >= 1 && TempDec <= 3) {
				TempDec -= 1;
				TempString += 'I';
				continue;
			}
		}
		//Update the object string variable with the fully formed numerals from the decimal value
		this->RomanNumeral = TempString;
	}

	//toStrings
	string toStringRoman(){
		return "Roman numeral is: " + this->RomanNumeral;
	}
	string toStringDecimal() {
		return "Decimal number is: " + to_string(this->DecimalNumber);
	}
};
//
//Main
//
int main(){
	//Initialize Class roman and variables for program use
	romanType roman;
	string RomanNumeral;
	int DecimalNumber;
	string UserInput;
	enum { Reset };
	bool bool1 = false;
	int Attempts = Reset;
	
	//Main do{}while() loop to run the program until the user decides to end the program
	do {
		//Ask user to determine which conversion method they wish to do
		cout << "Enter 1 to convert a Roman Numeral to a Decimal Number.\nEnter 2 to convert a Decimal Number to a Roman Numeral." << endl;
		cin >> UserInput;
		cout << endl;
		try {
			//If user wants to convert from roman numeral to decimal number
			if (!(UserInput.compare("1")) || !(UserInput.compare("2"))) {
				if (!(UserInput.compare("1"))) {
					//Validate RomanNumeral Input
					do {
						cout << "Enter a Roman Numeral: " << endl;
						cin >> RomanNumeral;
						cout << endl;
						//Try Catch to check that entry is Roman Numeral and handle errors
						try {
							for (int i = 0; i < RomanNumeral.length(); i++) {
								//Store string variable in a temp char to check each value of the string is a numeral
								char TempNumeral = RomanNumeral[i];
								if (TempNumeral == 'm' || TempNumeral == 'M' || TempNumeral == 'd' || TempNumeral == 'D'
									|| TempNumeral == 'c' || TempNumeral == 'C' || TempNumeral == 'l' || TempNumeral == 'L'
									|| TempNumeral == 'x' || TempNumeral == 'X' || TempNumeral == 'v' || TempNumeral == 'V' 
									|| TempNumeral == 'i' || TempNumeral == 'I') {
									//If proper characters are used capitlize any lowercase
									if (TempNumeral == 'm' || TempNumeral == 'd' || TempNumeral == 'c' || TempNumeral == 'l'
										|| TempNumeral == 'x' || TempNumeral == 'v' || TempNumeral == 'i') {
										//Use toupper from <string> funtions to capitilize the character
										RomanNumeral[i] = toupper(TempNumeral);
									}
									//If it makes it to this point without errors it is a roman numeral, change bool to true and end loop 
									if ((i == (RomanNumeral.length() - 1)) && (RomanNumeral[i] == 'M' || RomanNumeral[i] == 'D'
										|| RomanNumeral[i] == 'C' || RomanNumeral[i] == 'L' || RomanNumeral[i] == 'X' 
										|| RomanNumeral[i] == 'V' || RomanNumeral[i] == 'I')) {
										//Change bool1 to true and Set RomanNumeral before converting and outputting the results back to console through toString
										bool1 = true;
										roman.setRomanNumeral(RomanNumeral);
										roman.RomanToDecimal();
										cout << roman.toStringRoman() << ", after conversion, " << roman.toStringDecimal() << endl;
									}
								}
								else {
									//Throw error message into stream and increase loop count by 1
									Attempts++;
									throw string("Invalid Input For Roman Numeral. (M, D, C, L, X, V, I)\n");
								}
							}
						}
						catch (string err) {
							//Print error message and clear ostream so another catch doesn't pick it up
							cout << err << endl;
							cin.clear();
							cin.ignore(1, '/n');
						}
					//Loop will end after the attempts limit is reached or the proper entry is input
					} while (bool1 == false && Attempts <= 3);

					//Reset bool back to false and Reset Attempts to 0 using enum
					bool1 = false;
					Attempts = Reset;
				}

				//If user wants to convert from decimal number to roman numeral
				if (!(UserInput.compare("2"))) {
					//Validate Decimal Input
					do {
						cout << "Enter a Decimal Number: " << endl;
						cin >> DecimalNumber;
						cout << endl;
						try {
							//If entry doesn't fail and is a positive integer
							if ((!cin.fail()) && DecimalNumber > 0){
								//Change bool1 to true and Set Decimal Number before calling method to convert calling toStrings
								bool1 = true;
								roman.setDecimalNumber(DecimalNumber);
								roman.DecimalToRoman();
								cout << roman.toStringDecimal() << ", after conversion, " << roman.toStringRoman() << "\n" << endl;
							}
							else {
								//Throw error message into stream and increase loop count by 1
								Attempts++;
								throw string("Invalid Input. Positive Intergers Only.\n");
							}
						}
						catch (string err) {
							//Print error message and clear ostream so another catch doesn't pick it up
							cout << err << endl;
							cin.clear();
							cin.ignore(1, '\n');
						}
					} while (bool1 == false && Attempts <= 3);
					
					//Reset bool back to false and Reset Attempts to 0 using enum
					bool1 = false;
					Attempts = Reset;
				}
			}
			else {
				//Throw prompt if invalid input from user is entered from menu
				throw string("Invalid Input From Menu. (1 or 2)");
			}
		}
		catch (string err) {
			//Print error message and clear ostream so another catch doesn't pick it up
			cout << err << endl;
			cin.clear();
			cin.ignore(1, '\n');
		}

		//Prompt user to continue or to end program
		cout << "\nDo you have more to convert? ('y' to continue, press anything else to stop.)" << endl;
		cin >> UserInput;
		cout << endl;

	//Loop will continue until the user enters 'y'. Input does not need to be validated, just check for correct input.
	} while (!(UserInput.compare("y")));

	return 0;
}
Project Name: Roman to Decimal and back again
Author: Michael Krause
Last Update: 1/24/2022


Problem Prompt:
Write a program that converts a number entered in Roman numerals to decimal form. Your program should consist of a class, romanType. 
An object of romanType should do the following:

Store the number as a Roman numeral.
Convert and store the number into decimal form.
Print the number as a Roman numeral or decimal number as requested by the user. (Write two separate functions�one to print the 
number as a Roman numeral and the other to print the number as a decimal number.)

The decimal values of the Roman numerals are:
M 1000
D 500
C 100
L 50
X 10
V 5
I 1

Remember, a larger numeral preceding a smaller numeral means addition, so LX is 60. A smaller numeral preceding a larger numeral 
means subtrac- tion, so XL is 40. Any place in a decimal number, such as the 1s place, the 10s place, and so on, requires from zero 
to four Roman numerals. Test your program using the following Roman numerals: MCXIV, CCCLIX, and MDCLXVI.


My Implentation To Solve The Problem:
Class:
I created a class called romanType to create an object from the users entry that will accept a Roman Numeral and convert it to a 
Decimal Number or it will accept a Decimal Number and convert it into a Roman Numeral. The class contains private fields 
(String RomanNumeral) (int DecimalNumber) for the variables entered by the user. For public access the user is allowed to access the 
default constructor, a paramterized constructor, and a destructor. Accessors and Mutators to the private fields will return the 
corresponding variable or change the information stored in the corresponding variable. The two void methods are used for converting 
the input from the user. The final to methods are the toStringMethods used to return the data from the object in a detailed form. 

RomanToDecimal Method:
The RomanToDecimal void method will store the RomanNumeral entered by the user into a temporary string called UserString. The for 
loop will run through each index of the string and store it into a temporary char variable (Numeral1). The if statements will run 
through and check if the variable is a Roman Numeral. If so the value of the roman numeral is stored in a variable for later. The 
next if statement increases the index by 1 to check next letter stored in UserString to verify whether to add or subtract the two 
values. The nested if statements will determine if the first and second values should be added, else subtract the larger value by 
the smaller and add it to the running total for the conversion. When the for loop reaches the end of the UserString[] the else 
statement at the end will catch it and add it to the running total. When the for loop has run through the Roman Numeral the object 
variable will be updated with the final total from the method.

DecimalToRoman Method:
The DecimalToRoman void method will essentially do the same thing as the RomanToDecimal method but in reverse. The method will take 
the Decimal Number entered by the user stored in the object and copy it in an (int) variable. The variable goes into a while loop 
and through the series of if statements determining the current value and subtracting the proper amount from the variable. It then 
updates the temporary string variable with the proper Roman Numeral. Once the string variable is updated the continue command will 
start the loop over from the top. It always checks the value is >= 1000 before going to the next lowest value and so on. Once the 
(int) variable reaches zero the while loop will end and update the object variable for Roman Numeral with the string representation 
of the Decimal Number.

Main Method:
The Main program initializes the object romanType and variables for the program. The outer do{}while() loop is nested with a try 
catch to ensure proper input for menu. Once inside the program the user will be asked if they want to enter a Roman Numeral and 
convert it into a Decimal Number or if they want to enter a Decimal Number and have it converted into a Roman Numeral. If the user 
chooses to enter a Roman Numeral the program will verify the user input is a Roman Numeral before calling the proper method from 
the object class. If the user enters lower case letter they will be capitlized, but if the user enters a decimal or letters that are
not Roman Numerals the try block will throw an error to the catch block and inform the user of the error before allowing them to 
enter again. The user is given a limited number of attempts before the loop will end and the user will be asked to continue or end 
the program. When a proper Numeral is entered the program calls the proper methods to convert the Numeral to a Decimal. 

Nested Loops for conversion:
The loop to change a Decimal to a Numeral has an identical method to it for verifying the users input is a decimal. But we only need 
to make sure the value is a positive integer so it requires less of a check than the Roman to Decimal validation. If an improper 
value is entered or a letter instead of a number the try block will throw and error message to the catch block where it will print 
the error to the user and then clear the ostream so another catch block doesn't pick it up by accident. If valid input is entered 
by the user the proper methods are called from the object to store the number, convert the number, and then print the conversion 
back to the user. 

End Program:
The user is given the option to continue converting number or end the program. The program will only end if the user enters 'y' to 
end it. This seemed the simplest form to continue the loop. If the user enters anything else the program will end.

Testing:
I used the Roman Numerals MCXIV, CCCLIX, and MDCLXVI given in the prompt to test my program and got the results of 1114, 359, and 
1666 respectively. I used a myriad of other test Numerals as well as decimal values for converting decimal to numeral. I even 
attempted mixing letters and numbers to test my validation loops for both the Roman to Numeral and the Decimal to Numeral loops and 
everything has checked out and seems to be working perfectly. 